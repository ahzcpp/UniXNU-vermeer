#!/usr/bin/env python3
"""Keep verified UFS identity queries while disabling Virtio transport entry."""
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
HERE=Path(__file__).resolve().parent
if not __debug__:
    raise SystemExit('Run without -O: source identity checks are mandatory')
source=Path('/root/k70-clean-20261104/UniXNU/drivers/VirtioMmioBlock')
destination=HERE/'query-only-VirtioMmioBlock'
assert not destination.exists(),'Refuse to overwrite reviewed source copy'
revision=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
assert revision=='c1ecc5b74c9dc4ced13bcfbd81a2c3998025a5e5'
shutil.copytree(source,destination,ignore=shutil.ignore_patterns('.git','__pycache__'))
path=destination/'NativeVirtioBlock.cpp';original=path.read_text();text=original

def replace_body(text,signature,replacement):
    at=text.index(signature);start=text.index('{',at);depth=0
    for end in range(start,len(text)):
        if text[end]=='{':depth+=1
        elif text[end]=='}':
            depth-=1
            if depth==0:return text[:start]+replacement+text[end+1:]
    raise RuntimeError('Unbalanced original function')

text=replace_body(text,'IOService *NativeVirtioBlock::probe(IOService *provider, SInt32 *score)',
'''{
  // K70 uses this archive's unchanged authenticated-media query functions.
  // It must never select a Virtio MMIO backend on this physical handset.
  (void)provider; (void)score;
  return nullptr;
}''')
text=replace_body(text,'bool NativeVirtioBlock::start(IOService *provider)',
'''{
  // A second refusal boundary also covers a direct start request.
  (void)provider;
  return false;
}''')
path.write_text(text)
patch=''.join(difflib.unified_diff(original.splitlines(keepends=True),text.splitlines(keepends=True),
                                 fromfile='a/NativeVirtioBlock.cpp',tofile='b/NativeVirtioBlock.cpp'))
(HERE/'k70-virtio-query-only.patch').write_text(patch)
(HERE/'query-only-virtio-source.json').write_text(json.dumps({'original_revision':revision,
  'original_cpp_sha256':hashlib.sha256(original.encode()).hexdigest(),
  'query_only_cpp_sha256':hashlib.sha256(text.encode()).hexdigest(),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),
  'changed_functions':['NativeVirtioBlock::probe','NativeVirtioBlock::start'],
  'authenticated_media_query_functions_unchanged':True,'transport_entry_points_refuse':True,
  'original_source_modified':False,'compile_status':'pending real recipe'},indent=2)+'\n')
print(destination)
