#!/usr/bin/env python3
"""Compare supplied stock FDT storage resources with the pinned UFS source.

Metadata-only verification: no hardware access and no claim of runtime readiness.
Run in the existing Ubuntu build environment with fdtget installed.
"""
import hashlib
import json
from pathlib import Path
import re
import subprocess

BASE = Path('/mnt/e/K70-UniXNU-20261104')
DTB = BASE / 'stock-analysis/dtbo/vermeer-v2-composed.dtb'
DRIVER = Path('/root/k70-clean-20261104/out/feeds/ShengUfs-38c19c2b')
EXPECTED_REV = '99d8bcd3e43dd24fc3c8437c67b5d4cc71ab94d0'


def need(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def cells(node, prop):
    value = subprocess.check_output(['fdtget', '-t', 'x', str(DTB), node, prop], text=True)
    return [int(item, 16) for item in value.split()]


def string(node, prop):
    return subprocess.check_output(['fdtget', '-t', 's', str(DTB), node, prop], text=True).strip()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    revision = subprocess.check_output(['git', '-C', str(DRIVER), 'rev-parse', 'HEAD'], text=True).strip()
    need(revision == EXPECTED_REV, 'Unexpected UFS source revision')
    for name in ('GccUfs.h', 'NativeUfs.cpp'):
        original = subprocess.check_output(['git', '-C', str(DRIVER), 'show', EXPECTED_REV + ':' + name])
        need(original == (DRIVER / name).read_bytes(), 'Changed pinned driver input: ' + name)
    header = (DRIVER / 'GccUfs.h').read_text()
    source = (DRIVER / 'NativeUfs.cpp').read_text()
    constants = {}
    for name in ('UFS_HC_BASE', 'UFS_HC_SIZE'):
        match = re.search(r'^#define\s+' + name + r'\s+(0x[0-9a-fA-F]+)ULL\s*$', header, re.M)
        need(match is not None, 'Missing literal source constant ' + name)
        constants[name] = int(match.group(1), 16)
    need(cells('/soc', '#address-cells') == [1] and cells('/soc', '#size-cells') == [1],
         'Unsupported stock bus address/size cell format')
    ufs = '/soc/ufshc@1d84000'
    smmu = '/soc/apps-smmu@15000000'
    registers = cells(ufs, 'reg')
    need(registers[:2] == [constants['UFS_HC_BASE'], constants['UFS_HC_SIZE']], 'Stock UFS register window mismatch')
    need(string(ufs, 'status') in ('ok', 'okay'), 'Stock UFS is disabled')
    need(string(ufs, 'compatible') == 'qcom,ufshc', 'Unexpected stock UFS compatible')
    properties = subprocess.check_output(['fdtget', '-p', str(DTB), ufs], text=True).split()
    need('dma-coherent' in properties, 'Stock DT does not mark UFS coherent')
    iommu = cells(ufs, 'iommus')
    phandle = cells(smmu, 'phandle')
    need(len(phandle) == 1 and iommu == [phandle[0], 0x60, 0], 'Stock UFS SMMU stream mapping mismatch')
    smmu_regs = cells(smmu, 'reg')
    need(smmu_regs[:2] == [0x15000000, 0x100000], 'Unexpected stock application SMMU window')
    need('mapPhys (0x15000000ULL, 0xd0000, keep)' in source, 'Source SMMU mapping changed')
    need('smmuBypassStream (0x60, gHost.smmuMap, report, gHost.phys, kDmaBytes)' in source,
         'Source root path stream changed')
    result = dict(status='stock-metadata-matches-source', hardware_tested=False,
                  stock_dtb=str(DTB), stock_dtb_sha256=sha(DTB), driver_revision=revision,
                  source_sha256={name: sha(DRIVER / name) for name in ('GccUfs.h', 'NativeUfs.cpp')},
                  ufs=dict(path=ufs, registers=registers, interrupts=cells(ufs, 'interrupts'),
                           coherent=True, iommu=iommu), smmu=dict(path=smmu, registers=smmu_regs, phandle=phandle[0]),
                  runtime_unknown=['controller HCE/HCS and link state', 'SMMU matching group and context ownership',
                                   'DMA accessibility of the allocated buffer', 'LUN0 sector size and actual GPT',
                                   'successful authenticated OS/SystemOS read'])
    out = BASE / 'storage-next/stock-storage-verification.json'
    out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
