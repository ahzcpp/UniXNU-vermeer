#!/usr/bin/env python3
"""Prepare private FAT payload for the real storage kernel; never flash it."""
import hashlib,json,os,subprocess,sys,time,tomllib
from pathlib import Path
HERE=Path(__file__).resolve().parent
if not __debug__:raise SystemExit('Run without -O')
ROOT=Path('/root/k70-clean-20261104');WORK=ROOT/'storage-candidate-20261104';CORE=ROOT/'UniXNU'
DEVICE=WORK/'device';OUT=WORK/'out';TREE=OUT/'vermeer/ipados-17.7.11-21H461/vermeer/tree'
KERNEL=TREE.parent/'kernel/kernel.macho';FINAL=HERE/'final-storage-verification.json'
SEED=Path('/mnt/e/K70-UniXNU-20261104/system-next/cloud-fixed-41751537169/files/data-owners-fixed.dbr')
SEED_SHA='5f9a61d9788d03d1b81dd9571129c610a5e4a40949f1d426cc8e99c05034ce65'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads(FINAL.read_text())['final_kernel_sha256']==sha(KERNEL)
undefined=subprocess.check_output(['/usr/lib/llvm-18/bin/llvm-nm','--undefined-only',KERNEL],text=True)
assert not undefined.strip(),'Final prelinked candidate has unresolved symbols'
assert SEED.stat().st_size==1405072 and sha(SEED)==SEED_SHA
board=DEVICE/'board.toml';text=board.read_text()
title='title = "K70 storage01 RAM512 authenticated UFS + packed Data - UNTESTED"'
if title not in text:
    assert text.count('size_mib = 64')==1
    text=text.replace('size_mib = 64','size_mib = 128')
    old='title = "vermeer clean XNU baseline - root integration pending"';assert text.count(old)==1
    text=text.replace(old,title)
else:assert text.count(title)==1 and text.count('size_mib = 128')==1
board.write_text(text)
spec=tomllib.loads(text);args=spec['payload']['kernel_args']
assert spec['payload']['adt']['owned_memory_size']=='0x20000000'
assert spec['payload']['adt']['packed_data_ramdisk'] is True
assert spec['payload']['adt']['root_match_volume_uuid']=='04769D26-2CA0-4825-B443-E2E5F88300F2'
assert 'rd=md0' not in args and args.count('sheng-pmgr=2')==1 and args.count('native-ufs-root=1')==1
os.environ['UNIXNU_TOOLCHAIN']=str(WORK/'toolchain-view');os.environ['UNIXNU_UEFI']=str(ROOT/'uefi')
sys.path.insert(0,str(CORE/'scripts'))
from unixnu.cli import parser
from unixnu.config import Context
from unixnu import kernel,payload,ipsw
private=WORK/'payload-inputs';private.mkdir(exist_ok=True)
trust=private/'original-static-system.bundle'
if not trust.exists():
    subprocess.run([sys.executable,CORE/'scripts/bundle-ipsw-trust.py',trust,
                    ROOT/'out/ipsw/21H461/044-76040-038.dmg.trustcache',
                    ROOT/'out/ipsw/21H461/044-76034-038.dmg.trustcache'],check=True)
assert sha(trust)=='7416ca4f8377146626bb284e2133c76bee6cb4e3ee0af5d648b186235a7323a7'
assert sha(trust) in spec['payload']['trust_cache_sha256'],'Two unchanged target trust modules differ from board pin'
seed_id=json.loads(Path('/mnt/e/K70-UniXNU-20261104/local-inputs.json').read_text())['unique_chip_id']
command=['payload','-D',str(DEVICE),'--out',str(OUT),'--uefi',str(ROOT/'uefi'),'--kernel',str(KERNEL),
         '--data-ramdisk',str(SEED),'--trust-cache',str(trust),'--unique-chip-id',seed_id]
ctx=Context(parser().parse_args(command));ctx.uefi=ROOT/'uefi'
os.environ.update(kernel.linux_env(ctx))
os.environ['PATH']='/usr/lib/llvm-18/bin:'+os.environ['PATH']
os.environ.pop('CCC_OVERRIDE_OPTIONS',None)
assert not payload.paths(ctx)[1].exists(),'Refuse to overwrite payload output'
start=time.time();image=payload.build(ctx)
report={'status':'payload_built_pending_independent_readback','no_phone_io':True,'hardware_tested':False,
        'image':str(image),'image_bytes':image.stat().st_size,'image_sha256':sha(image),
        'native_prelinked_kernel_sha256':sha(KERNEL),'no_undefined_symbols':True,
        'final_base_storage_abi_proof_sha256':sha(FINAL),
        'corrected_data_seed':str(SEED),'corrected_data_seed_sha256':SEED_SHA,
        'data_uuid':'0BCD4E3F-5C8B-48FF-B0DD-4D7C81FF54BF','data_logical_bytes':3*1024**3,
        'root_uuid':spec['root']['os_volume_uuid'],'systemos_uuid':spec['root']['systemos_volume_uuid'],
        'required_owned_window_bytes':0x20000000,'fat_bytes':128*1024**2,'boot_b_capacity_bytes':192*1024**2,
        'ram_window_hardware_proven':False,'boot_image_not_created':True,'userdata_not_written':True,
        'private_contains_apple_kernel_and_trustcache':True,'seconds':round(time.time()-start,1)}
(HERE/'payload-build-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
