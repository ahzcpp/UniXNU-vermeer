#!/usr/bin/env python3
"""Fetch pinned public IOStorageFamily source into the isolated storage study."""
from pathlib import Path
import subprocess
root=Path(__file__).resolve().parent
if not __debug__:
    raise SystemExit('Run without -O: source identity checks are mandatory')
out=root/'refer/IOStorageFamily'
revision='e45fbe30a7879e0b16e26dddb78538f1b00e0bff'
url='https://github.com/apple-oss-distributions/IOStorageFamily'
if not out.exists():
    out.mkdir(parents=True)
    subprocess.run(['git','init','-q',str(out)],check=True)
    subprocess.run(['git','-C',str(out),'fetch','--depth','1',url,revision],check=True)
    subprocess.run(['git','-C',str(out),'checkout','--detach','--quiet','FETCH_HEAD'],check=True)
actual=subprocess.check_output(['git','-C',str(out),'rev-parse','HEAD'],text=True).strip()
assert actual==revision
assert not subprocess.check_output(['git','-C',str(out),'status','--porcelain'],text=True)
print(f'Pinned public IOStorageFamily {actual}: {out}')
