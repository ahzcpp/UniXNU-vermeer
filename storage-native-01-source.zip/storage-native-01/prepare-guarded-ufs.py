#!/usr/bin/env python3
"""Prepare a separate UFS source copy with early software ABI refusal checks."""
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
HERE=Path(__file__).resolve().parent
if not __debug__:
    raise SystemExit('Run without -O: source identity checks are mandatory')
source=Path('/root/k70-clean-20261104/storage-candidate-20261104/out/feeds/ShengUfs-38c19c2b')
pin=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
assert pin=='99d8bcd3e43dd24fc3c8437c67b5d4cc71ab94d0'
destination=HERE/'guarded-ShengUfs'
assert not destination.exists(),'Refuse to overwrite reviewed driver copy'
shutil.copytree(source,destination,ignore=shutil.ignore_patterns('.git','__pycache__'))
path=destination/'NativeUfs.cpp';original=path.read_text();text=original
marker='#include "SmmuTakeover.h"\n'
assert text.count(marker)==1
text=text.replace(marker,marker+'''
// K70 static proof uses the exact original iOS17 metaclass constructor operands.
// Compile-time type shape and runtime initialized metadata are distinct checks.
static_assert (sizeof (IOBlockStorageDevice) == 0x90, "K70 original storage base size");
static_assert (sizeof (IOService) == 0x88, "K70 source IOService size");
''')
marker='  gRootDiagnosticEnabled = diagnostic == 1;\n'
assert text.count(marker)==1
text=text.replace(marker,marker+'''  // Refuse before MMIO/queue/SMMU work if original-family initializers did
  // not establish the exact class size/parent proved from this kernel image.
  const OSMetaClass *blockClass = &IOBlockStorageDevice::gMetaClass;
  const OSMetaClass *serviceClass = &IOService::gMetaClass;
  if (blockClass->getClassSize () != sizeof (IOBlockStorageDevice) ||
      serviceClass->getClassSize () != sizeof (IOService) ||
      blockClass->getSuperClass () != serviceClass) {
    IOLog ("K70 UFS: initialized storage class ABI mismatch; no controller access\\n");
    rootDiagnosticFailure ("initialized storage class ABI mismatch");
    return false;
  }
''')
path.write_text(text)
patch=''.join(difflib.unified_diff(original.splitlines(keepends=True),text.splitlines(keepends=True),
                                  fromfile='a/NativeUfs.cpp',tofile='b/NativeUfs.cpp'))
(HERE/'k70-ufs-runtime-abi-guard.patch').write_text(patch)
(HERE/'guarded-ufs-source.json').write_text(json.dumps({
 'original_component_revision':pin,'original_cpp_sha256':hashlib.sha256(original.encode()).hexdigest(),
 'guarded_cpp_sha256':hashlib.sha256(text.encode()).hexdigest(),
 'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),
 'scope':'isolated source copy; original feeds and boot04 unchanged',
 'software_only_before_hardware':True,'runtime_guard_hardware_tested':False,
 'does_not_prove_earlier_static_class_registration_order':True,
 'compile_status':'pending actual recipe'},indent=2)+'\n')
print(destination)
