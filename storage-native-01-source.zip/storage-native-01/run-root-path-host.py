#!/usr/bin/env python3
"""Run pinned production-header tests with one Linux test-only type fix."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

base = Path('/mnt/e/K70-UniXNU-20261104/storage-next')
source = Path('/root/k70-clean-20261104/out/feeds/ShengUfs-38c19c2b')
copy = base / 'root-path-host-copy'
copy.mkdir(exist_ok=True)
for header in source.glob('*.h'):
    shutil.copy2(header, copy / header.name)
shutil.copytree(source / 'tests', copy / 'tests', dirs_exist_ok=True)
test = copy / 'tests/RootWindowRead.cpp'
original = test.read_text()
old = 'for(auto count:{0ULL,UINT64_MAX})'
assert original.count(old) == 1
test.write_text(original.replace(old, 'for(uint64_t count:{uint64_t{0},UINT64_MAX})'))
report = {'source_revision': subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip(),
          'test_only_change': 'Explicit uint64_t initializer avoids LP64 unsigned long/long long deduction conflict.',
          'production_headers_unchanged': all((copy/h.name).read_bytes() == h.read_bytes() for h in source.glob('*.h')),
          'source_test_sha256': hashlib.sha256(original.encode()).hexdigest(),
          'patched_test_sha256': hashlib.sha256(test.read_bytes()).hexdigest()}
result = subprocess.run(['python3','-u',str(copy/'tests/check_root_path_host.py'),
                         '--output',str(base/'root-path-tests'), '--openssl-prefix','/usr',
                         '--root-image','/root/k70-clean-20261104/out-system-candidate/ipados-17.7.11-two-window-candidate.img'])
report['test_exit_code'] = result.returncode
(base/'root-path-host-verification.json').write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(result.returncode)
