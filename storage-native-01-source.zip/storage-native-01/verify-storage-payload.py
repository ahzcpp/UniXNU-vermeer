#!/usr/bin/env python3
"""Read the written FAT independently; prove policy/seed/config and final ABI."""
import hashlib,json,os,shutil,struct,subprocess,sys,tomllib
from pathlib import Path
HERE=Path(__file__).resolve().parent
if not __debug__:raise SystemExit('Run without -O')
ROOT=Path('/root/k70-clean-20261104');WORK=ROOT/'storage-candidate-20261104'
BASE=WORK/'out/vermeer/ipados-17.7.11-21H461/vermeer';IMAGE=BASE/'payload/payload.img'
READBACK=WORK/'payload-readback';already_read=READBACK.exists()
READBACK.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
build=json.loads((HERE/'payload-build-result.json').read_text());metadata=json.loads((BASE/'payload/payload.json').read_text())
assert sha(IMAGE)==build['image_sha256']==metadata['payload_sha256']
if not already_read:subprocess.run(['mcopy','-i',IMAGE,'-s','::/EFI',READBACK],check=True)
inventory=subprocess.check_output(['mdir','-i',IMAGE,'-/','-b','::/EFI'],text=True).splitlines()
assert all(line.startswith('::/EFI/') for line in inventory)
files={line[3:]:READBACK/line[3:] for line in inventory if not line.endswith('/')}
prefix='EFI/UniXNU/';payloads=prefix+'Payloads/'
expected={prefix+'unixnu.toml',payloads+'kernel.macho',payloads+'kernel.macho.adt',
          payloads+'kernel.macho.trustcache',payloads+'scratch-data.img'}
assert set(files)==expected,'Unexpected FAT member or a missing required runtime input'
config=tomllib.loads(files[prefix+'unixnu.toml'].read_text())
assert config['version']==1 and config['boot']['default']=='xnu' and config['kits']['autoload'] is False
assert [e['id'] for e in config['entry']]==['xnu','reset','shutdown'] and 'driver' not in config
entry=config['entry'][0]
assert entry['title']=='K70 storage01 RAM512 authenticated UFS + packed Data - UNTESTED'
assert entry['type']=='xnu' and entry['path']=='Payloads/kernel.macho' and entry['initrd']=='Payloads/scratch-data.img'
arguments=entry['args'].split();assert entry['args']==metadata['kernel_args']
assert 'rd=md0' not in arguments and arguments.count('native-ufs-root=1')==arguments.count('sheng-pmgr=2')==1
assert not any(x.startswith(('sheng-data-reset=','sheng-disable-watchdogd=','sheng-lite=')) for x in arguments)
for member,key in [('kernel.macho','payload_kernel_sha256'),('kernel.macho.adt','adt_sha256'),
                   ('kernel.macho.trustcache','trust_cache_sha256'),('scratch-data.img','data_ramdisk_sha256')]:
    assert sha(files[payloads+member])==metadata[key]
seed=files[payloads+'scratch-data.img'];raw=seed.read_bytes()
assert sha(seed)==build['corrected_data_seed_sha256']=='5f9a61d9788d03d1b81dd9571129c610a5e4a40949f1d426cc8e99c05034ce65'
assert raw[:8]==b'DBRDISK1' and struct.unpack_from('<IIQ',raw,8)==(1,4096,3*1024**3)
assert len(raw)==1405072 and raw==Path(build['corrected_data_seed']).read_bytes()
trust=files[payloads+'kernel.macho.trustcache'].read_bytes();count=struct.unpack_from('<I',trust)[0]
assert count==2
offsets=struct.unpack_from('<2I',trust,4);assert offsets[0]==12 and 12<offsets[1]<len(trust)
modules=[trust[a:b] for a,b in zip(offsets,(*offsets[1:],len(trust)))]
assert [hashlib.sha256(x).hexdigest() for x in modules]==[
    'da88460e6e513438d5307e5c526f76497a74754476a24da29f239f0c90120fc2',
    'd121ba89167e03aafd00fa687c30cd8ebc4ccafd10c1408adb2ba3de12403651']
for module in modules:assert struct.unpack_from('<I',module)[0]==2 and len(module)==24+24*struct.unpack_from('<I',module,20)[0]
# Parse the Apple tree bytes read from FAT, independently of the generator.
adt=files[payloads+'kernel.macho.adt'].read_bytes();nodes={}
def node(offset,parent,depth=0):
    assert depth<64 and offset+8<=len(adt)
    props,children=struct.unpack_from('<II',adt,offset);assert props<4096 and children<4096;offset+=8;values={}
    for _ in range(props):
        assert offset+36<=len(adt)
        name=adt[offset:offset+32].split(b'\0',1)[0].decode('ascii');size=struct.unpack_from('<I',adt,offset+32)[0];offset+=36
        assert name not in values and offset+size<=len(adt)
        values[name]=adt[offset:offset+size];offset=(offset+size+3)&~3
    name=values['name'].rstrip(b'\0').decode('ascii');path=(parent+'/'+name).replace('//','/')
    if depth==0:assert name=='device-tree';path=''
    assert path not in nodes;nodes[path]=values
    for _ in range(children):offset=node(offset,path,depth+1)
    return offset
assert node(0,'')==len(adt)
chosen=nodes['/chosen'];mapping=nodes['/chosen/memory-map']
assert struct.unpack('<Q',chosen['darwinboot-memory-size'])==(0x20000000,)
root=chosen['root-matching'].rstrip(b'\0').decode('ascii')
assert root=='<dict><key>IOProviderClass</key><string>IOMedia</string><key>IOPropertyMatch</key><dict><key>UUID</key><string>04769D26-2CA0-4825-B443-E2E5F88300F2</string></dict></dict>'
assert mapping['PackedRAMDisk']==bytes(16) and 'RAMDisk' not in mapping and mapping['TrustCache']==bytes(16)
assert '/virtio' not in ''.join(nodes) and not any(b'virtio,mmio' in v for n in nodes.values() for v in n.values())
sys.path.insert(0,str(ROOT/'UniXNU/kits/XnuPrelink'));import native_prelink as np
kernel=files[payloads+'kernel.macho'];data=kernel.read_bytes();m=np.macho(data);names={n:v for v,ns in np.exports(data,m).items() for n in ns}
assert not subprocess.check_output(['/usr/lib/llvm-18/bin/llvm-nm','--undefined-only',kernel],text=True).strip()
all_symbols={}
sycmd=next(at for command,at,size in m['commands'] if command==2)
symoff,symcount,stroff,strbytes=struct.unpack_from('<4I',data,sycmd+8)
for index in range(symcount):
    strx,kind,section,description,address=struct.unpack_from('<IBBHQ',data,symoff+index*16)
    if kind&0xe0 or not kind&0xe:continue
    name=data[stroff+strx:data.index(b'\0',stroff+strx)].decode()
    all_symbols[name]=address
def read_symbol(name,size):
    address=names[name];offset=np.backed_offset(m['segments'],address,size,len(data));return data[offset:offset+size]
for policy,symbol in [('os','_verified_root_manifest'),('systemos','_verified_root_systemos_manifest')]:
    original=(ROOT/'out-root-policies'/('verified-root-'+policy)/'manifest.bin').read_bytes()
    assert read_symbol(symbol,len(original))==original,'Embedded full authenticated policy differs from actual C-verified original window'
key=(ROOT/'out-root-policies/verified-root-os/trusted-key.bin').read_bytes();assert read_symbol('_verified_root_key',len(key))==key
records=struct.unpack('<4Q',read_symbol('_verified_root_policies',32))
assert records==(names['_verified_root_manifest'],(ROOT/'out-root-policies/verified-root-os/manifest.bin').stat().st_size,
                 names['_verified_root_systemos_manifest'],(ROOT/'out-root-policies/verified-root-systemos/manifest.bin').stat().st_size)
assert struct.unpack('<Q',read_symbol('_verified_root_policy_count',8))==(2,)
for uuid in ('04769D26-2CA0-4825-B443-E2E5F88300F2','8846FE78-2910-4297-AF97-D59BB6F8FC16','0BCD4E3F-5C8B-48FF-B0DD-4D7C81FF54BF'):
    assert uuid.encode()+b'\0' in data,'Compiled identity missing: '+uuid
for name in ('_native_ufs_block_authenticates','_native_verified_block_root_authorized','_native_verified_block_volume_device','_sheng_pmgr_run','_sheng_boot_watchdog_policy',
             '__ZTV14NativeUfsBlock','__ZTV17NativeVirtioBlock','__ZTV14NativeRamBlock'):
    assert name in names,'Missing actual linked runtime dependency: '+name
# This static helper is inlined by the actual optimization recipe; require its
# real compile selection and emitted Data failure/identity strings, not a
# symbol the compiler is permitted to omit.
recipe=json.loads((BASE/'tree/build/xnu/ios-obj/DEVELOPMENT_ARM64_BCM2837/bsd/DEVELOPMENT/kern_exec.o.json').read_text().strip().rstrip(','))
compiler_args=recipe['arguments']
assert any(a=='-D' and b=='XNU_OWNER_DATA_MOUNT=1' for a,b in zip(compiler_args,compiler_args[1:]))
assert b'offline scratch Data mount failed:' in data and b'Data mount enter\0' in data
subprocess.run([sys.executable,HERE/'audit-data-callsite.py'],check=True)
data_calls=json.loads((HERE/'data-callsite-verification.json').read_text())
assert data_calls['final_payload_kernel_sha256']==sha(kernel) and data_calls['boundary']=='actual LC_FUNCTION_STARTS'
# The payload's entry/panic probe changes its private kernel COPY. Record that
# derivation, then independently inspect its actual final original-module bytes.
plan=json.loads((BASE/'kernel/kernel.json').read_text())
assert plan['candidate_sha256']==metadata['kernel_sha256']
plan['source_prelinked_candidate_sha256']=plan['candidate_sha256'];plan['candidate_sha256']=sha(kernel)
plan['output']=str(kernel)
plan['post_prelink_derivation']={'kind':'existing board entry/panic probe, no reset','log':str(BASE/'logs/payload-patch.log'),
                               'log_sha256':sha(BASE/'logs/payload-patch.log'),'original_prelink_record_unmodified':True}
kernel.with_suffix('.json').write_text(json.dumps(plan,indent=2)+'\n')
proof=HERE/'payload-final-storage-verification.json'
if not proof.exists():subprocess.run([sys.executable,HERE/'verify-final-storage.py','--kernel',kernel,'--output',proof],check=True)
else:
    existing=json.loads(proof.read_text())
    assert existing['final_kernel_sha256']==sha(kernel) and existing['all_16_original_aliases_identical']
    assert existing['vtable_190_independently_rederived_from_final_bytes']
report={'schema':'k70-storage-payload-readback-v1','all_fat_file_bytes_match':True,
        'files':{n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()},
        'fat_sha256':sha(IMAGE),'fat_bytes':IMAGE.stat().st_size,'payload_image':str(IMAGE),
        'payload_kernel_sha256':sha(kernel),'payload_original_storage_16_aliases_and_190_slots_pass':True,
        'full_two_volume_policy_bytes_match_c_verified_inputs':True,'original_static_and_system_trust_modules_unchanged':True,
        'real_corrected_seed_bytes_match':True,'packed_data_mapping_only':True,'no_3gib_expansion':True,
        'kernel_has_no_undefined_symbols':True,'kernel_os_systemos_data_uuid_strings_present':True,
        'actual_kern_exec_recipe_owner_data_enabled':True,'data_prepare_helper_symbol_present':'_native_owner_data_prepare' in all_symbols,
        'data_prepare_helper_missing_symbol_reason':'Static helper is optimized into load_init_program; actual final machine calls prove typed seed lookup, mount, and real policy execution remain',
        'data_prepare_inlining_proved_by_final_machine_calls':True,'data_callsite_proof_sha256':sha(HERE/'data-callsite-verification.json'),
        'required_owned_window_bytes':0x20000000,'actual_ram512_window_proven':False,
        'actual_ufs_io_qualified':False,'hardware_tested':False,'no_phone_io':True,'boot_image_created':False,
        'limitation':'Requires independently qualified RAM512 firmware and real LUN/queue/DMA/SMMU/root-media evidence; not a boot success claim'}
(HERE/'payload-readback-verification.json').write_text(json.dumps(report,indent=2)+'\n')
# Keep the original failed build/gate steps as history and attach new proof.
result=json.loads((WORK/'storage-integration-result.json').read_text())
result['status']='storage_kernel_prelinked_and_abi_verified_not_device_tested'
result['kernel']={'path':str(BASE/'kernel/kernel.macho'),'bytes':(BASE/'kernel/kernel.macho').stat().st_size,'sha256':metadata['kernel_sha256']}
result['final_gate_retry']={'passed':True,'proof':str(HERE/'final-storage-verification.json'),'reason':'Independent annotation compiler environment and explicit declaration slot classification'}
result['payload_readback']={'passed':True,'proof':str(HERE/'payload-readback-verification.json'),'final_abi_proof':str(proof)}
for destination in (WORK/'storage-integration-result.json',HERE/'kernel-integration-result.json'):destination.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='files'},indent=2))
