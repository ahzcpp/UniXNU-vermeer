# K70 存储链下一阶段

boot04 的本机结果已经经过 XNU 的 BSD 初始化，停在 `setconf` 后的
`failed to mount root device`。当前内核关闭了存储与 owner-root 链；这里
继续准备可重现的存储候选，旧 boot04 和基线均不修改。

## 已落实的静态 ABI 证据

`audit-static-storage.py` 读取确切的 run2 Mach-O 及 prelink 计划，要求原始
iPad7,1 kernelcache 为固定 `f18b4d…`，并逐字节核对原 IOStorageFamily
执行区。公共 IOStorageFamily 使用完整 pin `e45fbe30…`。

脚本从公共 iOS 声明编译一个**仅验证方法签名/顺序**的注释对象，并结合
实际原表证明 190 个槽：162 个源内核继承槽、14 个纯虚槽、14 个原存储
方法。注释对象不提供类大小证据、不链接、不执行。

原模块真正的 `__mod_init_func` 初始化器将 `0x90`、实际 IOService 父
metaclass、实际类名和本对象地址传给 OSMetaClass 构造器；源 IOService
构造器的大小参数为 `0x88`。protected constructor、base destructor、
抽象 D1/D0 的 BRK 以及 getMetaClass 指针均逐指令核对。

`static-abi/static-interface-audit.json` 明确是静态证据，不伪装成上游
要求 GDB 的 live audit。`static-original-bindings.S/.o` 只有 16 个绝对
符号别名，排除不可调用的抽象 D1/D0；对象所有 section 均为空，未复制
Apple 执行字节。此类绑定仍必须在最终 prelink 后再次确认地址/原码一致。

`bind-static-ufs.py` 只接受真正编译的 UFS / Virtio / RamBlock 对象：核对具体类全部190槽、
每个 override（包括原纯虚方法）的真实签名、实际基类 DWARF 的 `0x90/0x88`、
所有原类未定义导入和别名白名单，才产生独立 `libShengUfs.static.a`。
三个真实 clang24/iOS17 对象均已编译并通过该门。Virtio 归档提供唯一 alias
对象，UFS 和 RamBlock 引用同一 provider，避免 force_load 重复定义。
Virtio 的 probe/start 在专用副本中直接拒绝；其认证媒体查询函数保持原样，
仍沿实际 IOMedia/provider 链调用 UFS 认证，不能将它当成手机的 Virtio 传输。

## 实际编译与依赖

`bootstrap-kernel.py` 已完成新工作区的 source bootstrap 和 baseline prelink：
`/root/k70-clean-20261104/storage-candidate-20261104`。device 与九个 feeds
均为独立 git 工作树，仅共享只读对象；复用已有确切 kernelcache，不重新
下载 IPSW，不改旧输出。并行数上限4。

第一轮因 Linux host SETUP 工具缺 BSD `strlcat` 声明停止，结果保留。
`resume-bootstrap.py` 通过私有 toolchain-view 的 host wrapper 增加
`bsd/string.h`；原 toolchain 和目标编译器没有修改。状态和每轮日志见
`bootstrap-status.json`、WSL 工作区 `bootstrap-result.json` 与 `logs/`。

真实归档链需要：

1. 源内核 bootstrap 导出 headers，产生 IOPlatformExpert C++ 和 bsd_init C
   的真实 compile recipes；prepare-storage-headers 提供 pinned public headers。
2. ShengUfs 以 `NATIVE_VERIFIED_BLOCK=1`、`MULTI_POLICY=1` 编译具体类，再做
   上述严格静态绑定。普通 arm64 builder 本来就强制这些定义。
3. VirtioMmioBlock 必须使用 `--verified-root --verified-root-bundle`，再做
   同样的具体类绑定。owner-root 的三个媒体认证查询函数目前实现在这里，
   它们会沿真实 provider 链调用 UFS 的认证函数；仅打开配置或链接普通
   非 verified archive 不提供这些函数。不能为了链接成功改成允许认证。
4. 两卷真实 OS/SystemOS policy 使用同一个 owner anchor；root 已在
   `/root/k70-clean-20261104/out-root-policies/verified-root-{os,systemos}`
   完成全部 2,290,185 块的 C/RSA 验证。它们和私钥保持本地；本文不包含
   Apple 镜像、密钥、hash-table 二进制。
5. 合并两个配置片段：先 UFS/双卷认证链，再 typed RamBlock/真实 Data UUID。
   最终 native link 与 prelink 已完成，无未定义符号。`BootWatchdogPolicy.c`
   是旧设备补丁在 Data+BootProgress 下的实际依赖，已经按真实 BSD recipe
   编译归档；没有写 stub，也没有增加启用该可选策略的启动参数。

实际过程保留了初次 host、静态工具与链接闭包错误及修复日志，没有把失败
结果当成通过。当前编排脚本已包含这些 host recipe 与依赖闭包修复；实际
本轮用过的 `resume-bootstrap.py` / `resume-storage-link.py` 一并保留。
Policy C 生产源未修改；私有 host replay 去掉仅适用于 BSD 源的 clang24
`-Weverything` 集合，使用 `-Wall -Wextra -Werror` 及 unused-parameter 抑制。
BSD recipe 的空 libsa 导出 include 目录不造任何头文件。

## 已形成的完整私有 payload

原始 prelinked kernel 为 124,669,952B，SHA-256 `a95f2df80427587350e7d5fc504e409ef7bad59706783a88cc96018448d4feb5`。
原版 entry/panic-screen 工具只修改 payload 内副本；实际 FAT 读回副本 SHA-256
为 `962381af05f3eee0c41cd08708ffba34299693388220cc994598fb63728f70d5`。
两份最终字节均重推 190 槽、构造操作数、原存储代码和 16 个 alias，全部通过。
新 source IOService metaclass 地址改变时，实际原模块 GOT 父指针也已正确
重绑定；没有假定旧源内核地址保持不变。

`build-storage-payload.py` 使用 core payload builder 制成 128MiB FAT：

```
/root/k70-clean-20261104/storage-candidate-20261104/out/vermeer/ipados-17.7.11-21H461/vermeer/payload/payload.img
SHA256 f02a97df12648541b0fe1cb4ad337ecf8206fcd67e33a9fc052adc0eafcdfc64
```

`verify-storage-payload.py` 从实际 FAT 独立枚举、读回全部五个文件，核对完整
OS/SystemOS manifest 和 public anchor 与 C 已验证输入逐字节一致；两份
原版 trust module 重建 bundle 命中固定 `7416ca…`，不加入自签代码条目。
initrd 是真实修正权限种子 `data-owners-fixed.dbr`：编码 1,405,072B，
SHA-256 `5f9a61d9788d03d1b81dd9571129c610a5e4a40949f1d426cc8e99c05034ce65`，
逻辑容量3GiB；FAT/加载器保持 packed 输入，不在固件中展开3GiB。

ADT 只给 Data 预留 `PackedRAMDisk`，没有 `RAMDisk` 或 `rd=md0`；OS root
仍为 UFS 双卷。OS/SystemOS/Data UUID 分别为 `04769D26-2CA0-4825-B443-E2E5F88300F2`、
`8846FE78-2910-4297-AF97-D59BB6F8FC16`、`0BCD4E3F-5C8B-48FF-B0DD-4D7C81FF54BF`。

`native_owner_data_prepare` 在源中是 static，优化后不保留独立符号。
`data-callsite-verification.json` 通过真实 LC_FUNCTION_STARTS 界定最终
`load_init_program`，逐条解码实际 BL，确认 typed seed 查找、mount、真实
watchdog policy 调用仍在；同时核对真实编译 recipe 的 Data/RamBlock 定义。
这解释了报告里的 `data_prepare_helper_symbol_present: false`，不代表关闭 Data。

关键结果见 `kernel-integration-result.json`、`payload-readback-verification.json`、
`payload-final-storage-verification.json`、`data-callsite-verification.json`。
这些是离线构建与静态字节证据，尚未验证真实 Data 挂载或用户空间。

`package-storage-boot.py --fd PATH --fd-sha256 SHA --firmware-audit AUDIT --out FRESH_PRIVATE_DIR`
接收明确的成功 boot05 FD 审计及 SHA，组合这份固定 FAT 和已 pin 的原厂 v2
DTB，并独立解包核对 FD/FAT/stock splash 与192MiB boot_b 容量。
这个可逆的离线打包不要求 RAM512 真机先通过；脚本不操作手机。

## 真机条件

NativeUfs 不是一个空 stub：它有队列停止/接管、DMA、SMMU、SCSI读块、GPT、
manifest、签名核验和只读窗口发布代码。顶部“not a storage driver”旧注释
已落后于实现。但是它复用固件留下的 SM8550 host/PHY/request-list 状态，
不是已经为本 K70 验证的冷启动流程。

`hardware-inputs.template.json` 把原厂树已有资源与尚未读取的运行时事实分开。
K70 原厂树可支持核对 host 地址和 SID；不能由此推断 HCE/HCS、队列空闲、
SMMU context 归属、DMA可达、LUN、4K扇区或 GPT。驱动当前假定 LUN0/4096B，
下一步必须用真实结果确认或在明确证据下适配；不复制 sheng 的分区 LBA。

128MiB FAT 是磁盘容器容量，不能与运行时内存窗口混淆。旧 boot04 的128MiB
是入口实验预算。当前实现要把双卷完整 policy 表分配到内核内存，
仅 hash 表已需 73,285,920B，超过 boot04 观察到的约55MiB空闲页。把表改成
root-image 对象并不会省去现实现的这笔内存。真实根卷测试需要先证实更大
可用窗口；本候选 ADT 强制请求512MiB，尚无本机成功窗口证据，不能为塞进
旧128MiB而跳过认证。原始完整根卷候选不被这些工具修改或写入手机。

参考：[官方 UFS 移植流程](https://unixnu.com/porting/ufs)、
[ShengUfs 组件](https://unixnu.com/drivers/sheng-ufs)。本目录不执行 fastboot，
不写 userdata，也没有声称 UFS I/O、根卷挂载或用户空间已通过。
