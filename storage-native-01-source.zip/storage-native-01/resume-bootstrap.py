#!/usr/bin/env python3
"""Resume the isolated kernel work with a private host-compiler compatibility shim."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
ROOT=Path('/root/k70-clean-20261104')
if not __debug__:
    raise SystemExit('Run without -O: source identity checks are mandatory')
HERE=Path(__file__).resolve().parent
WORK=ROOT/'storage-candidate-20261104'
original=ROOT/'toolchain'
view=WORK/'toolchain-view'
assert (WORK/'bootstrap-result.json').is_file()
assert Path('/usr/include/bsd/string.h').is_file()
view.mkdir(exist_ok=True)
# Only the host compiler wrapper differs. All target tools/libraries are the
# same completed toolchain, exposed read-only through symlinks.
for source in original.iterdir():
    if source.name=='CommandLineTools':continue
    dest=view/source.name
    if not dest.exists():dest.symlink_to(source,target_is_directory=source.is_dir())
(view/'CommandLineTools').mkdir(exist_ok=True)
for source in (original/'CommandLineTools').iterdir():
    if source.name=='usr':continue
    dest=view/'CommandLineTools'/source.name
    if not dest.exists():dest.symlink_to(source,target_is_directory=source.is_dir())
(view/'CommandLineTools/usr').mkdir(exist_ok=True)
for source in (original/'CommandLineTools/usr').iterdir():
    if source.name=='bin':continue
    dest=view/'CommandLineTools/usr'/source.name
    if not dest.exists():dest.symlink_to(source,target_is_directory=source.is_dir())
bindir=view/'CommandLineTools/usr/bin';bindir.mkdir(exist_ok=True)
for source in (original/'CommandLineTools/usr/bin').iterdir():
    if source.name=='xnu-host-cc':continue
    dest=bindir/source.name
    if not dest.exists():dest.symlink_to(source,target_is_directory=source.is_dir())
wrapper=bindir/'xnu-host-cc'
contents='#!/bin/sh\n# Private host-only compatibility: glibc has no strlcat declaration.\nexec "'+str(original/'CommandLineTools/usr/bin/xnu-host-cc')+'" -include /usr/include/bsd/string.h "$@"\n'
if wrapper.exists():assert wrapper.read_text()==contents
else:wrapper.write_text(contents);wrapper.chmod(0o755)
record=json.loads((WORK/'bootstrap-result.json').read_text())
number=1+len([s for s in record['steps'] if s['name'].startswith('kernel-first')])
label=f'kernel-first-{number:02d}'
command=[sys.executable,ROOT/'UniXNU/unixnu','build','kernel','-D',WORK/'device','--out',WORK/'out',
         '--kernelcache',ROOT/'out/ipsw/21H461/kernelcache.decompressed','--jobs','4']
command=list(map(str,command));log=WORK/'logs'/f'{label}.log'
env=dict(os.environ,UNIXNU_TOOLCHAIN=str(view),JOBS='4')
start=time.time()
with log.open('w') as stream:
    process=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT,env=env)
    record.update(status='running',active_process={'name':label,'pid':process.pid,'log':str(log),'command':command},
                  host_compatibility={'scope':'private toolchain view, host only','reason':'SETUP replacecontents.c calls BSD strlcat; original host shim omitted declaration',
                                      'target_toolchain_modified':False,'wrapper':str(wrapper),'added_host_include':'/usr/include/bsd/string.h'})
    for target in (WORK/'bootstrap-result.json',HERE/'bootstrap-status.json'):target.write_text(json.dumps(record,indent=2)+'\n')
    print(f'Running {label} pid={process.pid}; log={log}',flush=True)
    code=process.wait()
record['steps'].append({'name':label,'command':command,'exit_code':code,'elapsed_seconds':round(time.time()-start,1),'log':str(log)})
record.pop('active_process',None);record['status']='bootstrap_kernel_complete_storage_binding_pending' if code==0 else 'failed'
for target in (WORK/'bootstrap-result.json',HERE/'bootstrap-status.json'):target.write_text(json.dumps(record,indent=2)+'\n')
if code:print(log.read_text(errors='replace')[-10000:],file=sys.stderr)
raise SystemExit(code)
