#!/usr/bin/env python3
"""Hard gate: prove storage ABI again from the FINAL prelinked candidate.

The reference supplies aliases for compilation; this independently rereads
final bytes and rejects any drift before an image can be considered packable.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
HERE=Path(__file__).resolve().parent
if not __debug__:
    raise SystemExit('Run without -O: final-candidate validation is mandatory')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--kernel',type=Path,required=True)
    parser.add_argument('--reference',type=Path,default=HERE/'static-abi/static-interface-audit.json')
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    assert not args.output.exists(),'Refuse to overwrite final-candidate proof'
    reference=json.loads(args.reference.read_text())
    with tempfile.TemporaryDirectory(prefix='k70-final-storage-') as tmp:
        work=Path(tmp)
        subprocess.run([sys.executable,HERE/'audit-static-storage.py','--kernel',args.kernel,'--out',work],check=True)
        final=json.loads((work/'static-interface-audit.json').read_text())
    assert final['candidate_sha256']==hashlib.sha256(args.kernel.read_bytes()).hexdigest()
    assert final['original_kernelcache_sha256']==reference['original_kernelcache_sha256']
    assert final['original_storage_code_sha256']==reference['original_storage_code_sha256']
    assert final['method_slots']==reference['method_slots']==190
    assert final['static_alias_allowlist']==reference['static_alias_allowlist'],'Original storage VM/alias target drift: rebuild and requalify, do not pack'
    assert len(final['static_alias_allowlist'])==16
    assert [m['reference_name'] for m in final['methods']]==[m['reference_name'] for m in reference['methods']], 'Final concrete dispatch names/order changed'
    assert [m['declaration_name'] for m in final['methods']]==[m['declaration_name'] for m in reference['methods']]
    report={'schema':'k70-final-storage-binding-proof-v1','final_kernel_sha256':final['candidate_sha256'],
            'reference_kernel_sha256':reference['candidate_sha256'],
            'final_original_storage_code_sha256':final['original_storage_code_sha256'],
            'original_storage_code_matches_reference':True,'all_16_original_aliases_identical':True,
            'vtable_190_independently_rederived_from_final_bytes':True,
            'final_initialized_operand_sizes':{'IOBlockStorageDevice':final['block_metaclass_initializer']['class_size_argument'],
                                              'IOService':final['source_ioservice_class_size_argument']},
            'final_source_ioservice_metaclass':final['source_ioservice_metaclass'],
            'final_storage_vtable':final['vtable'],'final_aliases':final['static_alias_allowlist'],
            'hardware_tested':False,'actual_io_qualified':False,
            'does_not_substitute_for_final_kernel_unresolved_symbol_or_root_policy_checks':True}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
