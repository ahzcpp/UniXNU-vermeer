#!/usr/bin/env python3
"""Close the real Data+BootProgress watchdog-policy link dependency and resume."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
if not __debug__:raise SystemExit('Run without -O')
ROOT=Path('/root/k70-clean-20261104');WORK=ROOT/'storage-candidate-20261104';CORE=ROOT/'UniXNU'
DEVICE=WORK/'device';OUT=WORK/'out';TREE=OUT/'vermeer/ipados-17.7.11-21H461/vermeer/tree'
LOGS=WORK/'storage-integration-logs';report=json.loads((WORK/'storage-integration-result.json').read_text())
assert (report['status']=='failed' and report['steps'][-1]['name']=='link-storage-native' or
        report['status']=='running' and report['steps'][-1]['name']=='archive-real-watchdog-policy')
failed_link=next(step for step in report['steps'] if step['name']=='link-storage-native')
assert '_sheng_boot_watchdog_policy' in Path(failed_link['log']).read_text()
os.environ['UNIXNU_TOOLCHAIN']=str(WORK/'toolchain-view');sys.path.insert(0,str(CORE/'scripts'))
from unixnu.cli import parser
from unixnu.config import Context
from unixnu import components,feeds,kernel,patches
arguments=['build','kernel','-D',str(DEVICE),'--out',str(OUT),'--kernelcache',str(ROOT/'out/ipsw/21H461/kernelcache.decompressed'),'--jobs','4']
ctx=Context(parser().parse_args(arguments));env=dict(os.environ,**kernel.linux_env(ctx))
def save():
    for path in (WORK/'storage-integration-result.json',HERE/'kernel-integration-result.json'):
        path.write_text(json.dumps(report,indent=2)+'\n')
def run(label,command,cwd=TREE):
    log=LOGS/(label+'.log');assert not log.exists();command=list(map(str,command));start=time.time()
    print('Running '+label+'; '+str(log),flush=True)
    with log.open('w') as stream:r=subprocess.run(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT)
    report['steps'].append({'name':label,'command':command,'exit_code':r.returncode,'seconds':round(time.time()-start,1),'log':str(log)})
    report['status']='running' if not r.returncode else 'failed';save()
    if r.returncode:print(log.read_text(errors='replace')[-8000:],file=sys.stderr);raise SystemExit(r.returncode)
source=DEVICE/'package/BootWatchdogPolicy.c';destination=TREE/'build/boot-watchdog-policy'
reuse='watchdog_policy_dependency' in report
destination.mkdir(exist_ok=reuse)
assert source.read_bytes()==(TREE/'kits/vermeer/BootWatchdogPolicy.c').read_bytes()
record_path=TREE/'build/xnu/ios-obj/DEVELOPMENT_ARM64_BCM2837/bsd/DEVELOPMENT/bsd_init.o.json'
record=json.loads(record_path.read_text().strip().rstrip(','));args=record['arguments'];command=[];i=0;obj=destination/'BootWatchdogPolicy.o'
while i<len(args):
    value=args[i]
    if value==record['file']:command.append(source)
    elif value=='-o':command+=['-o',obj];i+=1
    elif value in ('-MF','-MJ','-MT','-MQ'):i+=1
    elif value=='-Xclang' and i+1<len(args) and args[i+1].startswith('-W'):i+=1
    elif not value.startswith('-W') and value not in ('-MD','-MP','-MMD'):command.append(value)
    i+=1
command+=['-Wall','-Wextra','-Werror','-Wno-unused-parameter']
archive=destination/'libBootWatchdogPolicy.a'
if reuse:
    assert report['watchdog_policy_dependency']['source_sha256']==hashlib.sha256(source.read_bytes()).hexdigest()
    assert report['watchdog_policy_dependency']['archive_sha256']==hashlib.sha256(archive.read_bytes()).hexdigest()
else:
    run('compile-real-watchdog-policy',command,record['directory'])
    run('archive-real-watchdog-policy',['xcrun','ar','rcs',archive,obj])
report['watchdog_policy_dependency']={'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
  'archive':str(archive),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
  'reason':'Existing XNU_OWNER_DATA_MOUNT + XNU_BOOT_PROGRESS call the real policy hook before launchd',
  'runtime_source_modified':False,'enable_policy_boot_arguments_added':False};save()
config=DEVICE/'configs/vermeer_defconfig';text=config.read_text();old='CONFIG_XNU_EXTRA_LD_ARCHIVES=""'
assert text.count(old)==1
text=text.replace(old,'CONFIG_XNU_EXTRA_LD_ARCHIVES="-Wl,-force_load,{tree}/build/boot-watchdog-policy/libBootWatchdogPolicy.a"');config.write_text(text)
run('configure-watchdog-link',[sys.executable,CORE/'unixnu','defconfig','vermeer_defconfig','-D',DEVICE,'--out',OUT,'--jobs','4'])
ctx=Context(parser().parse_args(arguments));mods=components.resolve(ctx,feeds.resolve(ctx));feeds.attach_cached(ctx,mods);ctx.modules=mods
env.update(kernel.xnu_env(ctx));env.update(kernel.version_env(mods,ctx));env['UNIXNU_PATCH_LIST']=str(patches.prepare(ctx,mods));env['JOBS']='4'
env['UNIXNU_GENERATED_DIR']=str(TREE/'build/generated')
run('link-storage-native-closed',['bash',TREE/'scripts/build-xnu-4k-baseline.sh'])
try:result=kernel.prelink(ctx)
except Exception as error:
    report['status']='prelink_failed';report['prelink_error']=str(error);save();raise
run('final-storage-hard-gate',[sys.executable,HERE/'verify-final-storage.py','--kernel',result,'--output',HERE/'final-storage-verification.json'])
report['kernel']={'path':str(result),'bytes':result.stat().st_size,'sha256':hashlib.sha256(result.read_bytes()).hexdigest()}
report['status']='storage_kernel_prelinked_and_abi_verified_not_packaged_or_device_tested';save()
print(json.dumps(report['kernel'],indent=2))
