#!/usr/bin/env python3
"""Bind a REAL compiled NativeUfsBlock only after static dispatch verification.

No live/GDB audit is forged. This compile-only archive remains a hardware
candidate and needs runtime class initialization and controller qualification.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
import tempfile
HERE=Path(__file__).resolve().parent
sys.path.insert(0,'/root/k70-clean-20261104/UniXNU/kits/XnuPrelink')
import native_prelink as np

def require(condition,message):
    if not condition:raise SystemExit(message)
def sha(data):return hashlib.sha256(data).hexdigest()

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--object',type=Path,required=True)
    ap.add_argument('--component',choices=['ShengUfs','VirtioMmioBlock','RamBlock'],default='ShengUfs')
    ap.add_argument('--audit',type=Path,default=HERE/'static-abi/static-interface-audit.json')
    ap.add_argument('--kernel',type=Path,default=Path('/mnt/e/K70-UniXNU-20261104/artifacts/kernel-run2/kernel.macho'))
    ap.add_argument('--output',type=Path,default=HERE/'bound-ufs')
    ap.add_argument('--check-only',action='store_true')
    ap.add_argument('--alias-provider',type=Path,help='Other verified archive with bindings.json; omit duplicate absolute aliases from this archive')
    args=ap.parse_args();audit=json.loads(args.audit.read_text())
    require(audit['schema']=='k70-static-storage-dispatch-v1' and audit['method_slots']==190 and
            audit['metaclass_initialization_operands_verified'] and audit['abstract_complete_destructors_trap'],
            'Static dispatch/constructor qualification incomplete')
    require(sha(args.kernel.read_bytes())==audit['candidate_sha256'],'Wrong exact candidate identity')
    require(not audit['live_instance_sizes_verified'] and not audit['actual_io_qualified'],'Static-only report claims unexpected live qualification')
    alias_path=args.audit.parent/'static-original-bindings.o'
    aliases=audit['static_alias_allowlist']
    alias_data=alias_path.read_bytes()
    require(sha(alias_data)==audit['static_alias_object_sha256'],'Static alias object changed')
    am=np.macho(alias_data)
    require(am['kind']==1 and all(s['size']==0 for seg in am['segments'] for s in seg['sections']),'Alias object has executable/data payload')
    require({n:hex(v) for v,ns in np.exports(alias_data,am).items() for n in ns}==aliases,'Static aliases differ from allowlist')
    data=args.object.read_bytes();m=np.macho(data);require(m['kind']==1,'Concrete driver must be an ordinary ARM64 Mach-O object')
    version=next(at for c,at,n in m['commands'] if c==0x32)
    require(struct.unpack_from('<II',data,version+8)==(2,0x110000),'Concrete driver must target ordinary iOS 17')
    sycmd=next(at for c,at,n in m['commands'] if c==2)
    sy,count,st,_=struct.unpack_from('<4I',data,sycmd+8);symbols=[]
    for i in range(count):
        ix,kind,_,_,v=struct.unpack_from('<IBBHQ',data,sy+i*16)
        symbols.append((data[st+ix:data.index(b'\0',st+ix)].decode(),v,kind))
    runtime={'ShengUfs':'NativeUfsBlock','VirtioMmioBlock':'NativeVirtioBlock','RamBlock':'NativeRamBlock'}[args.component]
    mangled=str(len(runtime))+runtime
    vtable_hits=[v for n,v,k in symbols if n=='__ZTV'+mangled]
    require(len(vtable_hits)==1,'No unique REAL '+runtime+' vtable in object')
    vtable=vtable_hits[0];relocations={}
    for segment in m['segments']:
        for section in segment['sections']:
            if section['va']<=vtable<section['va']+section['size']:
                ro,rc=struct.unpack_from('<II',data,section['command_offset']+56)
                for i in range(rc):
                    address,word=struct.unpack_from('<II',data,ro+i*8)
                    if word>>27&1 and word>>28==0 and word>>25&3==3:
                        relocations[section['va']+address]=symbols[word&0xffffff][0]
    compiled=[relocations.get(vtable+16+i*8) for i in range(190)]
    require(all(compiled) and vtable+16+190*8 not in relocations and '___cxa_pure_virtual' not in compiled,
            'Concrete class has missing, extra or pure virtual methods')
    names=list(dict.fromkeys(compiled+[r['declaration_name'] for r in audit['methods']]))
    demangled=subprocess.check_output(['/usr/lib/llvm-18/bin/llvm-cxxfilt'],input='\n'.join(n[1:] for n in names)+'\n',text=True).splitlines()
    readable=dict(zip(names,demangled));overrides=0
    for row,actual in zip(audit['methods'],compiled):
        expected=row['reference_name'];declared=row['declaration_name']
        own=actual.startswith(('__ZN'+mangled,'__ZNK'+mangled))
        if expected=='___cxa_pure_virtual':
            require(own,'Required pure transport method was not implemented')
        elif actual!=expected:
            require(own,'Inherited vtable target changed at slot '+str(row['slot']))
        if own and row['slot'] not in (0,1):
            require(readable[actual].split('::',1)[1]==readable[declared].split('::',1)[1],
                    'Concrete method signature/position mismatch at slot '+str(row['slot']))
        overrides+=own
    undefined=[n for n,v,k in symbols if k==1 and 'IOBlockStorageDevice' in n]
    require(not any(re.search(r'IOBlockStorageDeviceD[01]Ev$',n) for n in undefined),'Abstract complete/deleting destructor may not be called')
    require(all(n in aliases for n in undefined),'Concrete object has an unqualified original class import')
    # This must be the real driver's compiled base type, not the tiny signature
    # annotation class. Runtime metaclass memory remains a separate condition.
    sizes={}
    for name,expected in [('IOBlockStorageDevice',0x90),('IOService',0x88)]:
        dwarf=subprocess.check_output(['/usr/lib/llvm-18/bin/llvm-dwarfdump','--name='+name,'--show-children',str(args.object)],text=True)
        match=re.search(r'DW_AT_name\s+\("'+name+r'"\)[\s\S]{0,250}?DW_AT_byte_size\s+\((0x[0-9a-f]+)\)',dwarf)
        require(match and int(match[1],16)==expected,'Actual compiled '+name+' size absent/wrong; compile real driver with -g -fstandalone-debug')
        sizes[name]=expected
    report={'schema':'k70-static-concrete-ufs-binding-v1','compiled_object_sha256':sha(data),
      'component':args.component,'runtime_class':runtime,
      'static_candidate_sha256':audit['candidate_sha256'],'static_audit_sha256':sha(args.audit.read_bytes()),
      'concrete_vtable_slots_verified':190,'concrete_overrides':overrides,'compiled_real_base_sizes':sizes,
      'original_imports':{n:aliases[n] for n in undefined},'unqualified_original_storage_imports':0,
      'bindings':aliases,
      'live_initialized_metaclass_verified':False,'actual_io_qualified':False,'hardware_tested':False,
      'requires_runtime_class_guard_and_hardware_qualification':True}
    members=[str(args.object),str(alias_path)]
    if args.alias_provider:
        provider=json.loads(args.alias_provider.with_name('bindings.json').read_text())
        require(provider['schema']=='k70-static-concrete-ufs-binding-v1' and provider['includes_static_alias_object'] and
                provider['static_candidate_sha256']==audit['candidate_sha256'] and
                provider['static_audit_sha256']==sha(args.audit.read_bytes()) and
                sha(args.alias_provider.read_bytes())==provider['archive_sha256'],
                'External alias provider does not match this exact static proof')
        report['external_static_alias_provider']={'archive':str(args.alias_provider),'archive_sha256':provider['archive_sha256']}
        members=[str(args.object)]
    report['includes_static_alias_object']=args.alias_provider is None
    if not args.check_only:
        require(not args.output.exists(),'Refuse to overwrite a completed binding candidate')
        args.output.mkdir(parents=True)
        archive=args.output/('lib'+args.component+'.static.a')
        subprocess.run(['/usr/lib/llvm-18/bin/llvm-ar','rcs',str(archive),*members],check=True)
        report['archive_sha256']=sha(archive.read_bytes())
        report['archive_bytes']=archive.stat().st_size
        (args.output/'bindings.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
