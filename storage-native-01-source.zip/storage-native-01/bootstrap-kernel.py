#!/usr/bin/env python3
"""Build a separate source-kernel bootstrap for real storage headers/recipes.

Copies git work trees from existing verified caches; it never writes boot04,
the baseline device, old output roots or a handset. No Apple image is fetched.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path('/root/k70-clean-20261104')
HERE=Path(__file__).resolve().parent
WORK=ROOT/'storage-candidate-20261104'
CORE=ROOT/'UniXNU'
TOOLCHAIN=ROOT/'toolchain'
SOURCE=ROOT/'device-committed'
KERNELCACHE=ROOT/'out/ipsw/21H461/kernelcache.decompressed'
CORE_PIN='c1ecc5b74c9dc4ced13bcfbd81a2c3998025a5e5'
if not __debug__:
    raise SystemExit('Run without -O: source identity checks are mandatory')

def head(path):return subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD'],text=True).strip()
assert head(CORE)==CORE_PIN
assert hashlib.sha256(KERNELCACHE.read_bytes()).hexdigest()=='f18b4df865405f2a287b84977d7aca745e056d656d9fc9df1662970ce2969de7'
assert not WORK.exists(), 'Refusing to overwrite independent build work'
WORK.mkdir();(WORK/'logs').mkdir()
record={'work':str(WORK),'pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'core_commit':CORE_PIN,'device_source_commit':head(SOURCE),'jobs':4,
        'no_phone_io':True,'no_apple_image_fetch':True,'steps':[],'status':'running'}
env=dict(os.environ,UNIXNU_TOOLCHAIN=str(TOOLCHAIN),JOBS='4')

def save():
    (WORK/'bootstrap-result.json').write_text(json.dumps(record,indent=2)+'\n')
    (HERE/'bootstrap-status.json').write_text(json.dumps(record,indent=2)+'\n')

def run(name,args):
    args=[str(x) for x in args];log=WORK/'logs'/f'{name}.log'
    print(f'Running {name}; log {log}',flush=True)
    start=time.time()
    with log.open('w') as stream:
        process=subprocess.Popen(args,stdout=stream,stderr=subprocess.STDOUT,env=env)
        record['active_process']={'name':name,'pid':process.pid,'log':str(log),'command':args};save()
        code=process.wait()
    record['steps'].append({'name':name,'command':args,'exit_code':code,'elapsed_seconds':round(time.time()-start,1),'log':str(log)})
    record.pop('active_process',None);save()
    if code:
        record['status']='failed';save()
        print(log.read_text(errors='replace')[-10000:],file=sys.stderr)
        raise SystemExit(code)

save()
run('clone-device',['git','clone','--shared','--no-hardlinks',SOURCE,WORK/'device'])
feedout=WORK/'out/feeds';feedout.mkdir(parents=True)
feed_records=[]
for source in sorted((ROOT/'out/feeds').iterdir()):
    if not (source/'.git').is_dir():continue
    destination=feedout/source.name
    run('seed-'+source.name,['git','clone','--shared','--no-hardlinks',source,destination])
    assert head(source)==head(destination)
    feed_records.append({'name':source.name,'commit':head(destination),'source':str(source)})
record['independent_feed_clones']=feed_records;save()
profile=WORK/'device/scripts/ci-build-profile.py'
run('first-pass-profile',[sys.executable,profile,'--drop-pmgr','--drop-gpu'])
common=['-D',WORK/'device','--out',WORK/'out','--kernelcache',KERNELCACHE,'--jobs','4']
run('configure',[sys.executable,CORE/'unixnu','defconfig','vermeer_defconfig',*common])
run('kernel-first',[sys.executable,CORE/'unixnu','build','kernel',*common])
tree=WORK/'out/vermeer/ipados-17.7.11-21H461/vermeer/tree'
paths={
  'iokit_recipe':tree/'build/xnu/ios-obj/DEVELOPMENT_ARM64_BCM2837/iokit/DEVELOPMENT/IOPlatformExpert.cpo.json',
  'bsd_recipe':tree/'build/xnu/ios-obj/DEVELOPMENT_ARM64_BCM2837/bsd/DEVELOPMENT/bsd_init.o.json',
  'native_ufs_object':tree/'build/sheng-ufs/NativeUfs.o',
  'native_ufs_archive':tree/'build/sheng-ufs/libShengUfs.a',
  'storage_header':tree/'build/storage-abi/include/IOKit/storage/IOBlockStorageDevice.h',
}
record['outputs']={name:{'path':str(p),'exists':p.is_file(),'bytes':p.stat().st_size if p.is_file() else None} for name,p in paths.items()}
record['status']='bootstrap_kernel_complete_storage_binding_pending';save()
print(json.dumps(record['outputs'],indent=2),flush=True)
