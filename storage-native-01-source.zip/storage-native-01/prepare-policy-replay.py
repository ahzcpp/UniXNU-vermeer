#!/usr/bin/env python3
"""Adapt only an isolated host recipe replay to its actual clang 24 compiler."""
import difflib
import hashlib
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
TREE=Path('/root/k70-clean-20261104/storage-candidate-20261104/out/vermeer/ipados-17.7.11-21H461/vermeer/tree')
path=TREE/'scripts/build-verified-root-probe.py'
original=Path('/root/k70-clean-20261104/UniXNU/scripts/build-verified-root-probe.py').read_text()
assert hashlib.sha256(original.encode()).hexdigest()=='244e46d945540855d43fd9ccd200ef37a722593d8877b7360ac3cf5ae411643e'
assert path.read_text()==original,'Refuse to change an already modified policy builder'
old="        elif value not in ('-MD', '-MP'):"
new="""        elif value == '-Xclang' and index + 1 < len(compile_args) and compile_args[index + 1].startswith('-W'):
            index += 1
        elif not value.startswith('-W') and value not in ('-MD', '-MP'):"""
assert original.count(old)==1
updated=original.replace(old,new)
old="    command += ['-I' + str(ROOT / 'kits/VerifiedRoot/include'), '-Werror']"
new="    command += ['-I' + str(ROOT / 'kits/VerifiedRoot/include'), '-Wall', '-Wextra', '-Werror', '-Wno-unused-parameter']"
assert updated.count(old)==1
updated=updated.replace(old,new)
path.write_text(updated)
(HERE/'policy-replay-clang24.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),updated.splitlines(True),
    fromfile='a/scripts/build-verified-root-probe.py',tofile='b/scripts/build-verified-root-probe.py')))
libsa=TREE/'build/xnu/ios-obj/EXPORT_HDRS/libsa'
libsa.mkdir(exist_ok=True)
assert libsa.is_dir() and not list(libsa.iterdir()),'Include compatibility path must be empty, never fabricated headers'
report={'original_builder_sha256':hashlib.sha256(original.encode()).hexdigest(),
        'isolated_builder_sha256':hashlib.sha256(updated.encode()).hexdigest(),
        'runtime_sources_modified':False,'scope':'Only this independent tree host recipe replay',
        'reason':'BSD recipe contains clang-24 Weverything warnings unrelated to kit C API; retain Wall,Wextra,Werror and actual target/header recipe',
        'unused_libsa_include_path_created_empty':str(libsa),
        'new_flags':['-Wall','-Wextra','-Werror','-Wno-unused-parameter']}
(HERE/'policy-replay-clang24.json').write_text(json.dumps(report,indent=2)+'\n')
