#!/usr/bin/env python3
"""Export an explicit UTF-8 text allowlist; never scan/include private binaries."""
import hashlib,json,shutil,subprocess,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=Path('/root/k70-clean-20261104');WORK=ROOT/'storage-candidate-20261104'
if not __debug__:raise SystemExit('Run without -O')
def sha(data):return hashlib.sha256(data).hexdigest()
integration=json.loads((HERE/'kernel-integration-result.json').read_text())
assert integration['status']=='storage_kernel_prelinked_and_abi_verified_not_device_tested'
readback=json.loads((HERE/'payload-readback-verification.json').read_text())
assert readback['data_prepare_inlining_proved_by_final_machine_calls'] and readback['all_fat_file_bytes_match']
boot=Path('/mnt/e/K70-UniXNU-20261104/artifacts/storage-native-01/verification.json')
boot_report=json.loads(boot.read_text());assert boot_report['offline_container_verified'] and not boot_report['hardware_tested']
shutil.copyfile(boot,HERE/'fullboot-offline-verification.json')
for component,source_report,directory in [('ShengUfs','guarded-ufs-source.json','bound-ufs'),('VirtioMmioBlock','query-only-virtio-source.json','bound-virtio')]:
    record=json.loads((HERE/source_report).read_text());binding=WORK/'storage-archives'/directory/'bindings.json';proof=json.loads(binding.read_text())
    assert proof['component']==component and proof['concrete_vtable_slots_verified']==190
    record['compile_status']='actual clang24/iOS17 object compiled; 190-slot and real DWARF binding passed; final prelink passed'
    record['compiled_object_sha256']=proof['compiled_object_sha256'];record['binding_report_sha256']=sha(binding.read_bytes())
    record['final_prelinked_candidate_sha256']=integration['kernel']['sha256'];record['runtime_hardware_tested']=False
    (HERE/source_report).write_text(json.dumps(record,indent=2)+'\n')
build=json.loads((HERE/'payload-build-result.json').read_text());build['status']='payload_built_and_independent_readback_verified'
build['readback_proof_sha256']=sha((HERE/'payload-readback-verification.json').read_bytes())
(HERE/'payload-build-result.json').write_text(json.dumps(build,indent=2)+'\n')
scripts=['audit-static-storage.py','bind-static-ufs.py','bootstrap-kernel.py','resume-bootstrap.py','continue-after-bootstrap.py',
         'build-storage-archives.py','integrate-kernel.py','resume-storage-link.py','prepare-guarded-ufs.py',
         'prepare-query-only-virtio.py','prepare-policy-replay.py','fetch-public-storage.py','verify-final-storage.py',
         'build-storage-payload.py','verify-storage-payload.py','audit-data-callsite.py','package-storage-boot.py',
         'verify-stock-storage.py','run-root-path-host.py','export-source-only.py']
documents=['README.md','storage-owner-no-data.fragment.config','storage-owner-packed-data.fragment.config','hardware-inputs.template.json',
           'k70-ufs-runtime-abi-guard.patch','k70-virtio-query-only.patch','policy-replay-clang24.patch']
evidence=['archive-build-report.json','kernel-integration-result.json','payload-build-result.json','payload-readback-verification.json',
          'payload-final-storage-verification.json','final-storage-verification.json','data-callsite-verification.json',
          'guarded-ufs-source.json','query-only-virtio-source.json','policy-replay-clang24.json','stock-storage-verification.json',
          'root-path-host-verification.json','fullboot-offline-verification.json']
selected={name:HERE/name for name in scripts+documents+evidence}
for name in ('static-interface-audit.json','static-original-bindings.S'):selected['static-abi/'+name]=HERE/'static-abi'/name
for directory in ('bound-ufs','bound-virtio','bound-ram'):
    selected['driver-evidence/'+directory+'.json']=WORK/'storage-archives'/directory/'bindings.json'
for name in ('board.toml','configs/vermeer_defconfig'):
    selected['generated-config/'+name]=WORK/'device'/name
bundle=HERE/'source-only';assert not bundle.exists(),'Refuse to replace a published source bundle';bundle.mkdir()
stage=bundle/'storage-native-01';stage.mkdir();manifest={}
secret=json.loads(Path('/mnt/e/K70-UniXNU-20261104/local-inputs.json').read_text())['unique_chip_id'].encode()
for member,path in selected.items():
    assert not Path(member).is_absolute() and '..' not in Path(member).parts
    data=path.read_bytes();data.decode('utf-8');assert b'\0' not in data and secret not in data
    assert Path(member).suffix in {'.py','.json','.md','.config','.patch','.S','.toml',''}
    assert len(data)<1024**2,'Unexpectedly large text input; review before export'
    destination=stage/member;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(data)
    manifest[member]={'bytes':len(data),'sha256':sha(data)}
metadata={'schema':'k70-storage-source-only-v1','files':manifest,
          'core_revision':'c1ecc5b74c9dc4ced13bcfbd81a2c3998025a5e5','device_source_revision':'f89fd56c8b262de98befcb0fb3f2a1178b64bde8',
          'ufs_revision':'99d8bcd3e43dd24fc3c8437c67b5d4cc71ab94d0','public_storage_revision':'e45fbe30a7879e0b16e26dddb78538f1b00e0bff',
          'no_apple_or_oem_binary_payloads':True,'no_seed_policy_sample_hash_table_or_private_key_binary':True,
          'all_members_utf8_text_without_nul':True,'unique_chip_seed_value_excluded':True,
          'binary_candidates_not_included':True,'offline_container_sha256':boot_report['image_sha256'],
          'hardware_tested':False,'scope':'Source helpers, source patches, exact config, and offline evidence only'}
manifest_bytes=(json.dumps(metadata,indent=2)+'\n').encode();(stage/'source-manifest.json').write_bytes(manifest_bytes)
archive=bundle/'storage-native-01-source.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as target:
    for member in sorted([*selected,'source-manifest.json']):
        info=zipfile.ZipInfo('storage-native-01/'+member,(1980,1,1,0,0,0));info.external_attr=0o644<<16
        target.writestr(info,(stage/member).read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(archive) as check:
    assert set(check.namelist())=={'storage-native-01/'+name for name in [*selected,'source-manifest.json']}
    assert check.read('storage-native-01/source-manifest.json')==manifest_bytes
    for member,proof in manifest.items():
        data=check.read('storage-native-01/'+member);assert len(data)==proof['bytes'] and sha(data)==proof['sha256']
result={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),
        'text_files':len(selected)+1,'readback_all_files_match':True,'apple_oem_or_seed_binaries_included':False,
        'source_manifest_sha256':sha(manifest_bytes),'hardware_tested':False}
(HERE/'source-only-export-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
