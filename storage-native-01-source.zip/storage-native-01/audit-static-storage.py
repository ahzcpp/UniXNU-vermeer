#!/usr/bin/env python3
"""Prove static IOStorageFamily dispatch from exact candidate bytes.

This produces a static-only report, never the upstream live GDB audit schema.
The tiny annotation class only establishes iOS method mangling/order. It is
not an instance-size test and its object is never linked into a kernel.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys
import tempfile

HERE=Path(__file__).resolve().parent
CORE=Path('/root/k70-clean-20261104/UniXNU')
sys.path.insert(0,str(CORE/'kits/XnuPrelink'))
import native_prelink as np

def require(condition, message):
    if not condition:raise SystemExit(message)

def sha(data):return hashlib.sha256(data).hexdigest()

def relative_branch(address, instruction):
    immediate=instruction&0x3ffffff
    if immediate&0x2000000:immediate-=0x4000000
    return address+immediate*4

def page_target(address, instruction):
    immediate=((instruction>>5&0x7ffff)<<2)|(instruction>>29&3)
    if immediate&0x100000:immediate-=0x200000
    return (address&~4095)+immediate*4096

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--kernel',type=Path,default=Path('/mnt/e/K70-UniXNU-20261104/artifacts/kernel-run2/kernel.macho'))
    parser.add_argument('--public-source',type=Path,default=HERE/'refer/IOStorageFamily')
    parser.add_argument('--out',type=Path,default=HERE/'static-abi')
    args=parser.parse_args(); out=args.out;out.mkdir(parents=True,exist_ok=True)
    compiler_env=dict(os.environ)
    # This annotation deliberately uses distro clang 18, not the target build's
    # clang 24 shim. Its injected CCC warning overrides are compiler-specific.
    compiler_env.pop('CCC_OVERRIDE_OPTIONS',None)
    revision=subprocess.check_output(['git','-C',str(args.public_source),'rev-parse','HEAD'],text=True).strip()
    require(revision=='e45fbe30a7879e0b16e26dddb78538f1b00e0bff','Unreviewed public header pin')
    require(not subprocess.check_output(['git','-C',str(args.public_source),'status','--porcelain'],text=True),'Dirty public source')
    header=(args.public_source/'IOBlockStorageDevice.h').read_text()
    storage=(args.public_source/'IOStorage.h').read_text()
    aliases={'IOStorageUnmapOptions':'UInt32','IOStoragePriority':'UInt8',
             'IOStorageSynchronizeOptions':'UInt32','IOStorageGetProvisionStatusOptions':'UInt64'}
    for name,kind in aliases.items():
        require(re.search(r'\btypedef\s+'+kind+r'\s+'+name+r'\s*;',storage),'Public typedef changed: '+name)
    declarations=header[header.index('virtual bool\tinit('):header.index('OSMetaClassDeclareReservedUsed(IOBlockStorageDevice,  0)')]
    annotation='''// Signature annotation only; not a model of IOService layout or class size.
#define TARGET_OS_OSX 0
#define APPLE_KEXT_OVERRIDE
typedef unsigned char UInt8;
typedef unsigned int UInt32;
typedef unsigned long long UInt64;
typedef int IOReturn;
typedef UInt32 IOStorageUnmapOptions, IOStorageSynchronizeOptions;
typedef UInt8 IOStoragePriority;
typedef UInt64 IOStorageGetProvisionStatusOptions;
class OSDictionary; class OSObject; class OSSymbol; class IOMemoryDescriptor;
struct IOStorageAttributes; struct IOStorageCompletion;
struct IOBlockStorageDeviceExtent; struct IOBlockStorageProvisionDeviceExtent;
class IOBlockStorageDevice { public:
'''+declarations+'''\n};
bool IOBlockStorageDevice::init(OSDictionary *) { return false; }
'''
    with tempfile.TemporaryDirectory(prefix='k70-storage-signatures-') as tmp:
        work=Path(tmp);cpp=work/'signatures.cpp';obj_path=work/'signatures.o';cpp.write_text(annotation)
        command=['/usr/lib/llvm-18/bin/clang++','-target','arm64-apple-ios17.0','-ffreestanding','-fno-exceptions','-fno-rtti',
                 '-nostdinc++','-Werror','-c',str(cpp),'-o',str(obj_path)]
        subprocess.run(command,check=True,env=compiler_env)
        ast_command=command[:command.index('-c')]+['-Xclang','-ast-dump=json','-fsyntax-only',str(cpp)]
        ast=json.loads(subprocess.check_output(ast_command,text=True,env=compiler_env))
        record=next(n for n in ast['inner'] if n.get('kind')=='CXXRecordDecl' and n.get('name')=='IOBlockStorageDevice' and n.get('completeDefinition'))
        declarations_in_order=[n['mangledName'] for n in record['inner'] if n.get('kind')=='CXXMethodDecl' and not n.get('isImplicit')]
        require(len(declarations_in_order)==25,'Public declaration AST count changed')
        # Darwin Clang already emits the Mach-O leading underscore in its AST
        # mangledName. Confirm against the real annotation object below rather
        # than adding a second prefix and creating an un-demangleable name.
        require(all(n.startswith(('__ZN','__ZNK')) for n in declarations_in_order),
                'Unexpected Darwin AST symbol spelling')
        obj=obj_path.read_bytes();om=np.macho(obj)
        sycmd=next(at for command,at,size in om['commands'] if command==2)
        symoff,count,stroff,_=struct.unpack_from('<4I',obj,sycmd+8)
        symbols=[]
        for i in range(count):
            ix,kind,_,_,value=struct.unpack_from('<IBBHQ',obj,symoff+i*16)
            symbols.append((obj[stroff+ix:obj.index(b'\0',stroff+ix)].decode(),value,kind))
        vtable=next(v for n,v,k in symbols if n=='__ZTV20IOBlockStorageDevice')
        relocations={}
        for segment in om['segments']:
            for section in segment['sections']:
                if section['va']<=vtable<section['va']+section['size']:
                    ro,rc=struct.unpack_from('<II',obj,section['command_offset']+56)
                    for i in range(rc):
                        address,word=struct.unpack_from('<II',obj,ro+i*8)
                        if word>>27&1 and word>>28==0 and word>>25&3==3:
                            relocations[section['va']+address]=symbols[word&0xffffff][0]
        annotation_names=[]
        while vtable+16+len(annotation_names)*8 in relocations:
            annotation_names.append(relocations[vtable+16+len(annotation_names)*8])
        require(len(annotation_names)==25 and annotation_names.count('___cxa_pure_virtual')==14,'iOS declaration dispatch shape changed')
        require(all(actual=='___cxa_pure_virtual' or actual==declared
                    for actual,declared in zip(annotation_names,declarations_in_order)),
                'Darwin AST names differ from actual annotation relocations')
    data=args.kernel.read_bytes();plan=json.loads(args.kernel.with_suffix('.json').read_text())
    require(sha(data)==plan['candidate_sha256'],'Candidate provenance mismatch')
    require(plan['original_sha256']=='f18b4df865405f2a287b84977d7aca745e056d656d9fc9df1662970ce2969de7','Wrong original iPad kernelcache')
    m=np.macho(data);exports=np.exports(data,m);by_name={n:v for v,ns in exports.items() for n in ns}
    def read(v,n):
        at=np.backed_offset(m['segments'],v,n,len(data));return data[at:at+n]
    extents=[e for e in plan['extents'] if e['module']=='com.apple.iokit.IOStorageFamily']
    const=next(e for e in extents if e['segment']=='__DATA_CONST');text=next(e for e in extents if e['segment']=='__TEXT_EXEC')
    require(sha(read(text['va'],text['size']))==plan['original_executable_sha256']['com.apple.iokit.IOStorageFamily'],'Original storage code changed')
    service_table=by_name['__ZTV9IOService']
    service_ptrs=struct.unpack('<170Q',read(service_table+16,170*8))
    require(all(service_ptrs[:168]) and service_ptrs[168:]==(0,0),'IOService vtable boundary changed')
    # Public overrides replace only init/getProperty/setProperties in the existing base order.
    overridden={}
    for method in annotation_names[:3]:
        suffix=method.split('IOBlockStorageDevice',1)[1]
        qualifier='__ZNK' if method.startswith('__ZNK') else '__ZN'
        hits=[i for i,p in enumerate(service_ptrs[:168]) for name in exports.get(p,[])
              if name.startswith(qualifier) and name.endswith(suffix)]
        require(len(hits)==1,'Cannot identify base override: '+method)
        overridden[hits[0]]=method
    require(len(overridden)==3,'Duplicate public base overrides')
    # ABI-generated structors/getMetaClass are independently proved below.
    overridden.update({0:'__ZN20IOBlockStorageDeviceD1Ev',1:'__ZN20IOBlockStorageDeviceD0Ev',
                       7:'__ZNK20IOBlockStorageDevice12getMetaClassEv'})
    methods=[]
    for i,p in enumerate(service_ptrs[:168]):
        names=exports.get(p,[]);require(names,'Unnamed IOService slot')
        methods.append(overridden.get(i,names[0]))
    methods+=annotation_names[3:]
    storage_owned=set(overridden)|{168+i for i,name in enumerate(annotation_names[3:]) if name!='___cxa_pure_virtual'}
    require(len(storage_owned)==14 and len(methods)-len(storage_owned)-annotation_names.count('___cxa_pure_virtual')==162,
            'Expected 162 inherited, 14 pure, 14 storage-owned methods')
    declaration_names={168+i:n for i,n in enumerate(declarations_in_order[3:])}
    declaration_names.update({index:name for index,name in overridden.items()})
    require(len(methods)==190,'Wrong final static method count')
    blob=read(const['va'],const['size']);found=[]
    for at in range(0,len(blob)-(190+4)*8+1,8):
        if blob[at:at+16]!=bytes(16):continue
        ptrs=struct.unpack_from('<190Q',blob,at+16)
        if blob[at+16+190*8:at+16+192*8]!=bytes(16):continue
        if all(ptrs[i]==by_name[n] for i,n in enumerate(methods) if n in by_name):found.append((const['va']+at,ptrs))
    require(len(found)==1,'Block vtable not uniquely identified by all native/pure targets')
    table,pointers=found[0]
    # A newly linked kernel legitimately exports our absolute storage aliases.
    # Classify by the actual declaration/override slots, never by whether the
    # symbol happened to be absent before those aliases were linked.
    require(all(n in by_name for i,n in enumerate(methods) if i not in storage_owned),
            'Missing native inherited/pure target')
    for i,n in enumerate(methods):
        if i in storage_owned:require(text['va']<=pointers[i]<text['va']+text['size'],'Storage-owned method outside unchanged code')
    def thunk_names(address):
        a,load,branch=struct.unpack('<3I',read(address,12))
        require(a&0x9f00001f==0x90000010 and load&0xffc003ff==0xf9400210 and branch==0xd61f0200,'Unknown original import thunk')
        slot=page_target(address,a)+(load>>10&4095)*8
        return exports.get(struct.unpack('<Q',read(slot,8))[0],[])
    constructors=[]
    for address in range(text['va'],text['va']+text['size']-32,4):
        words=struct.unpack('<8I',read(address,32))
        if (words[:2]!=(0xa9bf7bfd,0x910003fd) or words[2]&0xfc000000!=0x94000000 or
            words[3]&0x9f00001f!=0x90000008 or words[4]&0xffc003ff!=0x91000108 or
            words[5:]!=(0xf9000008,0xa8c17bfd,0xd65f03c0)):continue
        stored=page_target(address+12,words[3])+(words[4]>>10&4095)
        if stored==table+16:constructors.append((address,relative_branch(address+8,words[2])))
    require(len(constructors)==1 and '__ZN9IOServiceC2EPK11OSMetaClass' in thunk_names(constructors[0][1]),'Unqualified protected constructor')
    destructor=pointers[0]-4;word=struct.unpack('<I',read(destructor,4))[0]
    require(word&0xfc000000==0x14000000 and '__ZN9IOServiceD2Ev' in thunk_names(relative_branch(destructor,word)),'Unqualified base destructor')
    require(all(read(pointers[i],4)==struct.pack('<I',0xd4200020) for i in (0,1)),'Abstract destructors no longer traps')
    function=pointers[7];a,add,ret=struct.unpack('<3I',read(function,12))
    require(a&0x9f00001f==0x90000000 and add&0xffc003ff==0x91000000 and ret==0xd65f03c0,'Unqualified metaclass getter')
    meta=page_target(function,a)+(add>>10&4095)
    # Locate the actual module's __mod_init_func, not an arbitrary same-shaped
    # function. Its constructor arguments establish intended size and parent;
    # they do not substitute for observing initialized metaclass memory.
    module_header=np.backed_offset(m['segments'],next(e for e in extents if e['segment']=='__TEXT')['va'],32,len(data))
    module=np.macho(data,module_header)
    init_section=next(s for segment in module['segments'] for s in segment['sections'] if s['name']=='__mod_init_func')
    require(init_section['size']%8==0,'Malformed module initializer list')
    init_functions=struct.unpack('<'+'Q'*(init_section['size']//8),read(init_section['va'],init_section['size']))
    def adrp_add(address, first, second, register):
        require(first&0x9f00001f==0x90000000|register and
                second&0xffc003ff==0x91000000|(register<<5)|register,'Unexpected ADRP/ADD register data flow')
        return page_target(address,first)+(second>>10&4095)
    init_matches=[]
    for address in init_functions:
        require(text['va']<=address<text['va']+text['size'],'Initializer outside module text')
        words=struct.unpack('<15I',read(address,60))
        if words[:2]!=(0xa9bf7bfd,0x910003fd):continue
        if words[2]&0x9f00001f!=0x90000000 or words[3]&0xffc003ff!=0x91000000:continue
        this=adrp_add(address+8,words[2],words[3],0)
        if this!=meta:continue
        classname=adrp_add(address+16,words[4],words[5],1)
        require(read(classname,len(b'IOBlockStorageDevice\0'))==b'IOBlockStorageDevice\0','Wrong registration class name')
        require(words[6]&0x9f00001f==0x90000002 and words[7]&0xffc003ff==0xf9400042,'Unqualified parent metaclass load')
        parent_slot=page_target(address+24,words[6])+(words[7]>>10&4095)*8
        parent=struct.unpack('<Q',read(parent_slot,8))[0]
        require(parent==by_name['__ZN9IOService10gMetaClassE'],'Original block parent is not actual source IOService')
        require(words[8]==0x52801203 and words[9]&0xfc000000==0x94000000,'Original block size/constructor call changed')
        require('__ZN11OSMetaClassC2EPKcPKS_j' in thunk_names(relative_branch(address+36,words[9])),'Registration does not call actual OSMetaClass ctor')
        require(words[10]&0x9f00001f==0x90000008 and words[11]&0xffc003ff==0x91000108 and
                words[12:]==(0xf9000008,0xa8c17bfd,0xd65f03c0),'Registration epilogue/data flow changed')
        init_matches.append({'initializer':hex(address),'metaclass_this':hex(this),'name':hex(classname),
                             'parent_import_slot':hex(parent_slot),'parent_metaclass':hex(parent),'class_size_argument':0x90})
    require(len(init_matches)==1,'Missing/ambiguous actual IOBlockStorageDevice initializer')
    service_ctor=by_name['__ZN9IOService9MetaClassC2Ev']
    service_words=struct.unpack('<13I',read(service_ctor,52))
    require(service_words[:2]==(0xa9bf7bfd,0x910003fd),'Source IOService metaclass ctor prologue changed')
    service_name=adrp_add(service_ctor+8,service_words[2],service_words[3],1)
    require(read(service_name,10)==b'IOService\0' and service_words[6]==0x52801103,'Source IOService class size/name changed')
    require(service_words[7]&0xfc000000==0x94000000 and relative_branch(service_ctor+28,service_words[7])==by_name['__ZN11OSMetaClassC2EPKcPKS_j'],
            'Source IOService metaclass constructor target changed')
    aliases={n:pointers[i] for i,n in enumerate(methods) if i in storage_owned and not re.search(r'IOBlockStorageDeviceD[01]Ev$',n)}
    aliases.update({'__ZN20IOBlockStorageDeviceC2EPK11OSMetaClass':constructors[0][0],
                    '__ZN20IOBlockStorageDeviceD2Ev':destructor,
                    '__ZN20IOBlockStorageDevice10gMetaClassE':meta,'__ZTV20IOBlockStorageDevice':table})
    assembly='// Static addresses from the exact reviewed candidate; no Apple executable bytes.\n'
    assembly+='// Abstract complete/deleting destructors are intentionally not bound.\n'
    assembly+=''.join(f'.globl {name}\n.set {name}, {value:#x}\n' for name,value in sorted(aliases.items()))
    (out/'static-original-bindings.S').write_text(assembly)
    alias_object=out/'static-original-bindings.o'
    subprocess.run(['/usr/lib/llvm-18/bin/clang','-target','arm64-apple-ios17.0','-c',str(out/'static-original-bindings.S'),'-o',str(alias_object)],check=True,env=compiler_env)
    alias_bytes=alias_object.read_bytes();alias_image=np.macho(alias_bytes)
    require(alias_image['kind']==1 and all(s['size']==0 for segment in alias_image['segments'] for s in segment['sections']),
            'Static binding object unexpectedly contains executable/data payload')
    alias_exports=np.exports(alias_bytes,alias_image)
    require({name:address for address,names in alias_exports.items() for name in names}==aliases,'Static binding object values changed')
    result={'schema':'k70-static-storage-dispatch-v1','evidence_kind':'static original/candidate bytes; not a live ABI observation',
      'candidate_sha256':sha(data),'original_kernelcache_sha256':plan['original_sha256'],
      'public_source_revision':revision,'public_header_sha256':sha(header.encode()),
      'annotation_source_sha256':sha(annotation.encode()),'annotation_object_sha256':sha(obj),
      'annotation_only_mangling_and_declaration_order':True,'annotation_executed_or_linked':False,
      'annotation_class_size_not_used':True,'public_new_virtual_slots':22,
      'method_slots':190,'native_inherited_slots':162,'pure_virtual_slots':14,'storage_owned_slots':14,
      'vtable':hex(table),'original_metaclass':hex(meta),'source_ioservice_metaclass':hex(by_name['__ZN9IOService10gMetaClassE']),
      'original_protected_constructor':hex(constructors[0][0]),'original_base_destructor':hex(destructor),
      'abstract_complete_destructors_trap':True,'original_storage_code_sha256':sha(read(text['va'],text['size'])),
      'methods':[{'slot':i,'reference_name':n,'declaration_name':declaration_names.get(i,n),'candidate_target':hex(pointers[i]),'kernel_names':exports.get(pointers[i],[])} for i,n in enumerate(methods)],
      'live_instance_sizes_verified':False,'metaclass_initialization_operands_verified':True,
      'block_metaclass_initializer':init_matches[0],
      'source_ioservice_metaclass_constructor':hex(service_ctor),'source_ioservice_class_size_argument':0x88,
      'static_alias_allowlist':{n:hex(v) for n,v in aliases.items()},
      'static_alias_assembly_sha256':sha(assembly.encode()),
      'static_alias_object_sha256':sha(alias_bytes),'static_alias_object_has_no_executable_or_data_payload':True,
      'actual_io_qualified':False,'hardware_tested':False,
      'pending':['Compile complete concrete NativeUfsBlock against real exported XNU headers and audit every concrete vtable relocation',
                 'Runtime class/super checks must refuse a different initialized ABI before block construction']}
    (out/'static-interface-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['methods']},indent=2))

if __name__=='__main__':main()
