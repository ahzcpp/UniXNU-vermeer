#!/usr/bin/env python3
"""Link the reviewed storage/policy/Data-config candidate in the isolated tree.

This never packs/flashes an image or consumes an uncorrected Data seed. The
configuration binds the measured Data UUID for the future packed-seed image.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
HERE=Path(__file__).resolve().parent
if not __debug__:raise SystemExit('Run without -O: kernel integration validation is mandatory')
ROOT=Path('/root/k70-clean-20261104');WORK=ROOT/'storage-candidate-20261104'
CORE=ROOT/'UniXNU';DEVICE=WORK/'device';OUT=WORK/'out'
TREE=OUT/'vermeer/ipados-17.7.11-21H461/vermeer/tree'
ARCHIVES=WORK/'storage-archives';LOGS=WORK/'storage-integration-logs'
assert json.loads((ARCHIVES/'archive-build-report.json').read_text())['status']=='archives_compiled_and_static_bound_kernel_integration_pending'
assert not LOGS.exists(),'Refuse to overwrite prior integration results'
LOGS.mkdir()
os.environ['UNIXNU_TOOLCHAIN']=str(WORK/'toolchain-view')
sys.path.insert(0,str(CORE/'scripts'))
from unixnu.cli import parser
from unixnu.config import Context
from unixnu import components,feeds,kernel,patches
base_args=['build','kernel','-D',str(DEVICE),'--out',str(OUT),'--kernelcache',str(ROOT/'out/ipsw/21H461/kernelcache.decompressed'),'--jobs','4']
base_ctx=Context(parser().parse_args(base_args))
env=dict(os.environ,**kernel.linux_env(base_ctx))
report={'status':'running','steps':[],'no_phone_io':True,'boot04_modified':False,
        'data_seed_not_packed_by_this_script':True,'corrected_packed_seed_required_before_packaging':True}
def save():
    (WORK/'storage-integration-result.json').write_text(json.dumps(report,indent=2)+'\n')
    (HERE/'kernel-integration-result.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,command,cwd=TREE):
    command=list(map(str,command));log=LOGS/(label+'.log');start=time.time()
    print(f'Running {label}; log {log}',flush=True)
    with log.open('w') as output:result=subprocess.run(command,cwd=cwd,env=env,stdout=output,stderr=subprocess.STDOUT)
    report['steps'].append({'name':label,'command':command,'exit_code':result.returncode,'seconds':round(time.time()-start,1),'log':str(log)})
    save()
    if result.returncode:
        report['status']='failed';save();print(log.read_text(errors='replace')[-10000:],file=sys.stderr);raise SystemExit(result.returncode)

# Keep the first actual new-source prelink result for the PMGR ABI builder.
first=base_ctx.work/'kernel/kernel.macho'
reference=TREE/'build/native-prelink/native-owner-ufs-cpu-desktop-bootstrap0-candidate.macho'
reference.parent.mkdir(parents=True,exist_ok=True)
assert not reference.exists()
shutil.copyfile(first,reference)
shutil.copyfile(first.with_suffix('.json'),reference.with_suffix('.json'))
report['bootstrap_reference_sha256']=hashlib.sha256(first.read_bytes()).hexdigest();save()

# Restore source configuration only inside this new device clone, then retain
# the deliberate GPU exclusion and add the reviewed storage closures.
for name in ('board.toml','configs/vermeer_defconfig'):
    data=subprocess.check_output(['git','-C',str(ROOT/'device-committed'),'show','HEAD:'+name])
    (DEVICE/name).write_bytes(data)
run('drop-gpu',[sys.executable,DEVICE/'scripts/ci-build-profile.py','--drop-gpu'])
config=DEVICE/'configs/vermeer_defconfig';text=config.read_text()
for fragment in ('storage-owner-no-data.fragment.config','storage-owner-packed-data.fragment.config'):
    for line in (HERE/fragment).read_text().splitlines():
        if not line.startswith('CONFIG_'):continue
        key=line.split('=',1)[0]
        pattern=r'(?m)^'+re.escape(key)+r'=.*$'
        if re.search(pattern,text):text=re.sub(pattern,lambda m:line,text)
        else:text+='\n'+line+'\n'
text+='\nCONFIG_XNU_VERIFIED_ROOT_ARCHIVE="{tree}/build/verified-root-os-xnu-bundle/libVerifiedRootProbe.a"\n'
empty_extra='CONFIG_XNU_EXTRA_LD_ARCHIVES=""'
assert text.count(empty_extra)==1
text=text.replace(empty_extra,'CONFIG_XNU_EXTRA_LD_ARCHIVES="-Wl,-force_load,{tree}/build/boot-watchdog-policy/libBootWatchdogPolicy.a"')
config.write_text(text)
board=DEVICE/'board.toml';blob=board.read_bytes()
assert blob.count(b'packed_data_ramdisk = false')==1
blob=blob.replace(b'packed_data_ramdisk = false',b'packed_data_ramdisk = true')
assert b'"native-ufs-root=1"' not in blob
needle=b'  "-no_slto_panic",'
assert blob.count(needle)==1
blob=blob.replace(needle,needle+b'\n  "native-ufs-root=1",\n  "native-ufs-diagnostics=1",')
assert b'"RamBlock"' not in blob
needle=b'"VirtioMmioBlock",'
assert blob.count(needle)==1
blob=blob.replace(needle,needle+b' "RamBlock",',1)
needle=b'  "component:ShengUfs",'
assert blob.count(needle)==1
blob=blob.replace(needle,needle+b'\n  "component:RamBlock",')
assert b'\n[root]' not in blob
policies={name:json.loads((ROOT/'out-root-policies'/('verified-root-'+name)/'verification.json').read_text()) for name in ('os','systemos')}
blob+=('\n[root]\nos_volume_uuid = "'+policies['os']['volume_uuid']+'"\nsystemos_volume_uuid = "'+policies['systemos']['volume_uuid']+
        '"\nos_image_sha256 = "'+policies['os']['image_sha256']+'"\nsystemos_image_sha256 = "'+policies['systemos']['image_sha256']+'"\n').encode()
board.write_bytes(blob)
run('configure-storage',[sys.executable,CORE/'unixnu','defconfig','vermeer_defconfig','-D',DEVICE,'--out',OUT,'--jobs','4'])
ctx=Context(parser().parse_args(base_args))
mods=components.resolve(ctx,feeds.resolve(ctx));feeds.attach_cached(ctx,mods);ctx.modules=mods
env.update(kernel.xnu_env(ctx));env.update(kernel.version_env(mods,ctx))
env['UNIXNU_PATCH_LIST']=str(patches.prepare(ctx,mods));env['JOBS']='4'
generated=TREE/'build/generated';generated.mkdir(parents=True,exist_ok=True)
env['UNIXNU_GENERATED_DIR']=str(generated)

def install_file(source,target):
    target.parent.mkdir(parents=True,exist_ok=True)
    assert target.parent.resolve().is_relative_to(TREE.resolve()),target
    if target.is_symlink():target.unlink()
    shutil.copyfile(source,target)
    assert hashlib.sha256(source.read_bytes()).digest()==hashlib.sha256(target.read_bytes()).digest()

for component,runtime,directory,bound in [('VirtioMmioBlock','NativeVirtioBlock','virtio-mmio-block','bound-virtio'),
                                         ('ShengUfs','NativeUfs','sheng-ufs','bound-ufs'),('RamBlock','NativeRamBlock','ram-block','bound-ram')]:
    source=ARCHIVES/bound/('lib'+component+'.static.a')
    proof=json.loads((source.parent/'bindings.json').read_text())
    assert hashlib.sha256(source.read_bytes()).hexdigest()==proof['archive_sha256']
    target=TREE/'build'/directory
    install_file(source,target/('lib'+component+'.a'))
    install_file(source.parent/'bindings.json',target/'bindings.json')
    install_file(ARCHIVES/(runtime+'.o'),target/(runtime+'.o'))
    # The consuming script's RAM/Virtio pair check derives this compatibility
    # name from the canonical archive stem; its bytes equal the real object.
    if runtime!=component:install_file(ARCHIVES/(runtime+'.o'),target/(component+'.o'))
report['archive_stage_complete']=True;report['data_uuid']='0BCD4E3F-5C8B-48FF-B0DD-4D7C81FF54BF';save()
watchdog_source=DEVICE/'package/BootWatchdogPolicy.c'
assert watchdog_source.read_bytes()==(TREE/'kits/vermeer/BootWatchdogPolicy.c').read_bytes()
watchdog_dir=TREE/'build/boot-watchdog-policy';watchdog_dir.mkdir()
watchdog_object=watchdog_dir/'BootWatchdogPolicy.o'
record_path=TREE/'build/xnu/ios-obj/DEVELOPMENT_ARM64_BCM2837/bsd/DEVELOPMENT/bsd_init.o.json'
record=json.loads(record_path.read_text().strip().rstrip(','));arguments=record['arguments'];command=[];index=0
while index<len(arguments):
    value=arguments[index]
    if value==record['file']:command.append(watchdog_source)
    elif value=='-o':command+=['-o',watchdog_object];index+=1
    elif value in ('-MF','-MJ','-MT','-MQ'):index+=1
    elif value=='-Xclang' and index+1<len(arguments) and arguments[index+1].startswith('-W'):index+=1
    elif not value.startswith('-W') and value not in ('-MD','-MP','-MMD'):command.append(value)
    index+=1
command+=['-Wall','-Wextra','-Werror','-Wno-unused-parameter']
run('compile-real-watchdog-policy',command,record['directory'])
watchdog_archive=watchdog_dir/'libBootWatchdogPolicy.a'
run('archive-real-watchdog-policy',['xcrun','ar','rcs',watchdog_archive,watchdog_object])
report['watchdog_policy_dependency']={'source':str(watchdog_source),'source_sha256':hashlib.sha256(watchdog_source.read_bytes()).hexdigest(),
    'archive':str(watchdog_archive),'archive_sha256':hashlib.sha256(watchdog_archive.read_bytes()).hexdigest(),
    'runtime_source_modified':False,'enable_policy_boot_arguments_added':False};save()
run('compile-pmgr',[sys.executable,TREE/'scripts/build-sheng-platform-power.py'])
run('link-storage-native',['bash',TREE/'scripts/build-xnu-4k-baseline.sh'])
try:
    result=kernel.prelink(ctx)
except Exception as error:
    report['status']='prelink_failed';report['prelink_error']=str(error);save();raise
run('final-storage-hard-gate',[sys.executable,HERE/'verify-final-storage.py','--kernel',result,'--output',HERE/'final-storage-verification.json'])
report['kernel']={'path':str(result),'bytes':result.stat().st_size,'sha256':hashlib.sha256(result.read_bytes()).hexdigest()}
report['status']='storage_kernel_prelinked_and_abi_verified_not_packaged_or_device_tested';save()
print(json.dumps({k:v for k,v in report.items() if k!='steps'},indent=2))
