#!/usr/bin/env python3
"""Prove the optimized owner-Data path from the final payload kernel's calls."""
import hashlib,json,struct,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=Path('/root/k70-clean-20261104');WORK=ROOT/'storage-candidate-20261104'
BASE=WORK/'out/vermeer/ipados-17.7.11-21H461/vermeer';KERNEL=WORK/'payload-readback/EFI/UniXNU/Payloads/kernel.macho'
if not __debug__:raise SystemExit('Run without -O')
sys.path.insert(0,str(ROOT/'UniXNU/kits/XnuPrelink'));import native_prelink as np
data=KERNEL.read_bytes();m=np.macho(data);names={n:v for v,ns in np.exports(data,m).items() for n in ns}
start=names['_load_init_program'];segments=m['segments'];section=next(s for segment in segments for s in segment['sections'] if s['va']<=start<s['va']+s['size'])
assert section['name']=='__text'
# The next exported text function is a conservative upper boundary. Prefer the
# actual LC_FUNCTION_STARTS boundary when its table covers this new source text.
end=min(v for v in names.values() if start<v<section['va']+section['size'])
boundary='next exported text symbol'
commands=[at for command,at,size in m['commands'] if command==0x26]
if commands:
    assert len(commands)==1
    offset,size=struct.unpack_from('<II',data,commands[0]+8);raw=data[offset:offset+size]
    base=next(s['va'] for s in segments if s['name']=='__TEXT');current=base;functions=[];index=0
    while index<len(raw):
        delta=0;shift=0
        while True:
            assert index<len(raw) and shift<64
            value=raw[index];index+=1;delta|=(value&127)<<shift;shift+=7
            if not value&128:break
        if not delta:break
        current+=delta;functions.append(current)
    if start in functions and any(x>start for x in functions):
        end=min(x for x in functions if x>start);boundary='actual LC_FUNCTION_STARTS'
assert start<end and end-start<65536
targets={name:names[name] for name in ('_native_ram_block_volume_seed','_mount','_sheng_boot_watchdog_policy')}
hits={name:[] for name in targets}
for address in range(start,end,4):
    at=np.backed_offset(segments,address,4,len(data));instruction=struct.unpack_from('<I',data,at)[0]
    if instruction&0xfc000000!=0x94000000:continue
    immediate=instruction&0x3ffffff
    if immediate&0x2000000:immediate-=0x4000000
    target=address+immediate*4
    for name,value in targets.items():
        if target==value:hits[name].append({'pc':hex(address),'instruction':hex(instruction),'target':hex(target)})
assert all(hits.values()),'Real load_init_program region must call typed seed lookup, mount, and real watchdog policy'
recipe=BASE/'tree/build/xnu/ios-obj/DEVELOPMENT_ARM64_BCM2837/bsd/DEVELOPMENT/kern_exec.o.json'
record=json.loads(recipe.read_text().strip().rstrip(','));arguments=record['arguments']
defines={b for a,b in zip(arguments,arguments[1:]) if a=='-D'}
assert {'XNU_OWNER_DATA_MOUNT=1','XNU_NATIVE_RAM_BLOCK=1'}<=defines
source=BASE/'tree/.cache/xnu-work/bsd/kern/kern_exec.c';text=source.read_text()
assert 'static int\nnative_owner_data_prepare' in text and 'int data_error = native_owner_data_prepare(p, (user_addr_t)scratch_addr);' in text
report={'schema':'k70-final-data-callsite-v1','final_payload_kernel_sha256':hashlib.sha256(data).hexdigest(),
        'actual_compiled_recipe_sha256':hashlib.sha256(recipe.read_bytes()).hexdigest(),
        'actual_kern_exec_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'helper_is_static_in_source':True,'helper_absent_as_export_expected_when_inlined':True,
        'load_init_program_start':hex(start),'checked_end_exclusive':hex(end),'boundary':boundary,
        'actual_machine_bl_calls':hits,'native_data_mount_selected_in_real_recipe':True,
        'typed_native_ram_provider_selected_in_real_recipe':True,'data_path_absence_not_inferred_from_missing_helper_symbol':True,
        'hardware_tested':False,'actual_data_mount_success':False}
(HERE/'data-callsite-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
