#!/usr/bin/env python3
"""Wait for this task's independent bootstrap, then compile its archives."""
import json
from pathlib import Path
import subprocess
import sys
import time
HERE=Path(__file__).resolve().parent
status=Path('/root/k70-clean-20261104/storage-candidate-20261104/bootstrap-result.json')
print('Waiting for independent bootstrap before any archive compilation',flush=True)
while True:
    record=json.loads(status.read_text())
    if record['status']=='failed':raise SystemExit('Bootstrap failed; archive stage not started')
    if record['status']=='bootstrap_kernel_complete_storage_binding_pending':break
    time.sleep(10)
raise SystemExit(subprocess.call([sys.executable,HERE/'build-storage-archives.py']))
