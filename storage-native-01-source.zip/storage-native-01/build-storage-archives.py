#!/usr/bin/env python3
"""Compile isolated real UFS/verified-Virtio archives and the real policy bundle.

Requires the independent source bootstrap to finish first. Integration changes
only this isolated candidate configuration, never boot04 or any phone partition.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from types import SimpleNamespace
HERE=Path(__file__).resolve().parent
if not __debug__:
    raise SystemExit('Run without -O: isolated archive validation is mandatory')
ROOT=Path('/root/k70-clean-20261104')
WORK=ROOT/'storage-candidate-20261104'
TREE=WORK/'out/vermeer/ipados-17.7.11-21H461/vermeer/tree'
OUT=WORK/'storage-archives'
sys.path.insert(0,str(ROOT/'UniXNU/scripts'))
from unixnu.kernel import linux_env
sys.path.insert(0,str(ROOT/'UniXNU/kits/XnuPrelink'))
import native_prelink as np
os.environ['UNIXNU_TOOLCHAIN']=str(WORK/'toolchain-view')
env=dict(os.environ,**linux_env(SimpleNamespace(tree=TREE)))
status=json.loads((WORK/'bootstrap-result.json').read_text())
assert status['status']=='bootstrap_kernel_complete_storage_binding_pending','Wait for complete bootstrap; do not race its archive outputs'
# This only adapts a private host replay; the real verified_root.c/crypto
# adapter/probe sources and the cryptographic validation remain unchanged.
policy_replay=json.loads((HERE/'policy-replay-clang24.json').read_text()) if (HERE/'policy-replay-clang24.json').exists() else None
if policy_replay is None:
    subprocess.run([sys.executable,HERE/'prepare-policy-replay.py'],check=True)
    policy_replay=json.loads((HERE/'policy-replay-clang24.json').read_text())
assert hashlib.sha256((TREE/'scripts/build-verified-root-probe.py').read_bytes()).hexdigest()==policy_replay['isolated_builder_sha256']
resume=sys.argv[1:] in (['--resume-bind-only'],['--resume-policy-only'])
policy_resume=sys.argv[1:]==['--resume-policy-only']
assert resume or not sys.argv[1:],'Unsupported arguments'
if resume:
    report=json.loads((OUT/'archive-build-report.json').read_text())
    assert report['status']=='failed' and set(report['compiled'])=={'NativeUfs','NativeVirtioBlock','NativeRamBlock'}
    assert report['steps'][-1]['exit_code']!=0
    assert report['steps'][-1]['name']==('compile-real-policy-bundle' if policy_resume else 'bind-verified-virtio')
    report.setdefault('resume_reasons',[]).append('Isolated policy recipe replay compatibility; production C remains unchanged' if policy_resume else
        'Darwin AST names already have Mach-O underscore; static annotation now cross-checks actual relocations')
else:
    assert not OUT.exists(),'Refuse to overwrite completed archive work'
    OUT.mkdir();(OUT/'logs').mkdir()
    report={'status':'running','hardware_tested':False,'actual_io_qualified':False,'steps':[]}

def save():
    (OUT/'archive-build-report.json').write_text(json.dumps(report,indent=2)+'\n')
    (HERE/'archive-build-report.json').write_text(json.dumps(report,indent=2)+'\n')

def run(label,command,cwd=TREE):
    command=list(map(str,command));log=OUT/'logs'/f'{label}.log';start=time.time()
    if log.exists():log=log.with_name(f'{label}-{len(report["steps"]):02}.log')
    print(f'Running {label}; {log}',flush=True)
    with log.open('w') as stream:result=subprocess.run(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT)
    report['steps'].append({'name':label,'command':command,'exit_code':result.returncode,'seconds':round(time.time()-start,1),'log':str(log)})
    save()
    if result.returncode:
        report['status']='failed';save();print(log.read_text(errors='replace')[-10000:],file=sys.stderr);raise SystemExit(result.returncode)

headers=OUT/'include/IOKit/storage';headers.mkdir(parents=True,exist_ok=resume)
public=HERE/'refer/IOStorageFamily'
for path in sorted(public.glob('*.h')):shutil.copyfile(path,headers/path.name)
shutil.copyfile(TREE/'.cache/fakeroot/usr/include/TargetConditionals.h',OUT/'include/TargetConditionals.h')
record_path=TREE/'build/xnu/ios-obj/DEVELOPMENT_ARM64_BCM2837/iokit/DEVELOPMENT/IOPlatformExpert.cpo.json'
record=json.loads(record_path.read_text().strip().rstrip(','))

def compile_driver(component,source,definitions):
    destination=OUT/(component+'.o');arguments=record['arguments'];command=[];index=0
    if resume:
        proof=report['compiled'][component]
        assert hashlib.sha256(destination.read_bytes()).hexdigest()==proof['sha256']
        assert hashlib.sha256(source.read_bytes()).hexdigest()==proof['source_sha256']
        assert hashlib.sha256(record_path.read_bytes()).hexdigest()==proof['recipe_sha256']
        return destination
    while index<len(arguments):
        value=arguments[index]
        if value==record['file']:command.append(str(source))
        elif value=='-o':command+=['-o',str(destination)];index+=1
        elif value in ('-MF','-MJ','-MT','-MQ'):index+=1
        elif value=='-Xclang' and index+1<len(arguments) and arguments[index+1].startswith('-W'):index+=1
        elif not value.startswith('-W') and value not in ('-MD','-MP','-MMD'):command.append(value)
        index+=1
    command+=['-g','-fstandalone-debug','-Wall','-Wextra','-Werror','-Wno-unused-parameter',
              '-Wno-c99-designator','-Wno-reorder-init-list','-Wno-deprecated-enum-enum-conversion',
              '-Wno-unnecessary-virtual-specifier','-I',str(TREE/'.cache/xnu-work/osfmk'),
              '-I',str(OUT/'include'),'-I',str(TREE/'kits/VerifiedRoot/include'),
              '-I',str(TREE/'drivers/VirtioMmioBlock'),*definitions]
    run('compile-'+component,command,record['directory'])
    blob=destination.read_bytes();image=np.macho(blob);assert image['kind']==1
    report.setdefault('compiled',{})[component]={'object':str(destination),'bytes':len(blob),
       'sha256':hashlib.sha256(blob).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
       'recipe_sha256':hashlib.sha256(record_path.read_bytes()).hexdigest()};save()
    return destination

ufs=compile_driver('NativeUfs',HERE/'guarded-ShengUfs/NativeUfs.cpp',
                   ['-DNATIVE_VERIFIED_BLOCK=1','-DNATIVE_VERIFIED_BLOCK_MULTI_POLICY=1','-mgeneral-regs-only'])
virtio=compile_driver('NativeVirtioBlock',HERE/'query-only-VirtioMmioBlock/NativeVirtioBlock.cpp',
                      ['-DNATIVE_VERIFIED_BLOCK=1','-DNATIVE_VERIFIED_BLOCK_MULTI_POLICY=1'])
ram=compile_driver('NativeRamBlock',ROOT/'UniXNU/drivers/RamBlock/NativeRamBlock.cpp',[])
if policy_resume:
    for component,runtime,directory in [('VirtioMmioBlock','NativeVirtioBlock','bound-virtio'),
                                      ('ShengUfs','NativeUfs','bound-ufs'),('RamBlock','NativeRamBlock','bound-ram')]:
        proof=json.loads((OUT/directory/'bindings.json').read_text())
        assert proof['component']==component and proof['concrete_vtable_slots_verified']==190
        assert proof['compiled_object_sha256']==report['compiled'][runtime]['sha256']
        assert proof['static_audit_sha256']==hashlib.sha256((HERE/'static-abi/static-interface-audit.json').read_bytes()).hexdigest()
        assert proof['archive_sha256']==hashlib.sha256((OUT/directory/('lib'+component+'.static.a')).read_bytes()).hexdigest()
else:
    run('bind-verified-virtio',[sys.executable,HERE/'bind-static-ufs.py','--component','VirtioMmioBlock','--object',virtio,'--output',OUT/'bound-virtio'])
    run('bind-guarded-ufs',[sys.executable,HERE/'bind-static-ufs.py','--component','ShengUfs','--object',ufs,'--output',OUT/'bound-ufs',
                          '--alias-provider',OUT/'bound-virtio/libVirtioMmioBlock.static.a'])
    run('bind-packed-data-ram',[sys.executable,HERE/'bind-static-ufs.py','--component','RamBlock','--object',ram,'--output',OUT/'bound-ram',
                             '--alias-provider',OUT/'bound-virtio/libVirtioMmioBlock.static.a'])

# The original public builder expects these paths relative to the isolated tree.
# Keep policies/keys outside Git; only public anchor and exact verified records
# are used by the resulting candidate archive.
for name in ('os','systemos'):
    source=ROOT/'out-root-policies'/('verified-root-'+name)
    metadata=json.loads((source/'verification.json').read_text())
    assert metadata['real_c_signature_and_block_verification'] and not metadata['hardware_tested']
    destination=TREE/'build'/('verified-root-'+name)
    if policy_resume:assert destination.is_symlink() and destination.resolve()==source.resolve()
    else:
        assert not destination.exists();destination.symlink_to(source,target_is_directory=True)
volumes=TREE/'.cache/firmware/target-volumes';volumes.mkdir(parents=True,exist_ok=True)
image=ROOT/'out/ipsw/21H461/044-76034-038.dmg';target=volumes/image.name
if policy_resume:assert target.is_symlink() and target.resolve()==image.resolve()
else:
    assert not target.exists();target.symlink_to(image)
run('compile-real-policy-bundle',[sys.executable,TREE/'scripts/build-verified-root-probe.py','--component','os','--include-systemos'])
policy=TREE/'build/verified-root-os-xnu-bundle/libVerifiedRootProbe.a'
assert policy.is_file()
report['policy_archive']={'path':str(policy),'bytes':policy.stat().st_size,'sha256':hashlib.sha256(policy.read_bytes()).hexdigest(),
                          'contains_actual_apple_image_sample_bytes':True,'private_binary_not_for_git':True,
                          'contains_signed_hash_tables_and_public_anchor':True,'contains_private_key':False}
report['status']='archives_compiled_and_static_bound_kernel_integration_pending';save()
print(json.dumps({k:v for k,v in report.items() if k!='steps'},indent=2))
print('Continuing isolated native kernel integration; no payload or phone operation',flush=True)
raise SystemExit(subprocess.call([sys.executable,HERE/'integrate-kernel.py'],env=env))
